import os
import pickle
import args_parser
import matplotlib.pyplot as plt

with open('/mnt/data2/tianming_data/models/transformer_model/model_state_dict.pkl', 'rb') as fp:
        state_dict = pickle.load(fp)

# args = args_parser.parse_args()
# ml = state_dict['min_loss']
# en = state_dict['min_loss_epochs']
# lr = state_dict['learning_rate']
# print(f'resume training, with the min val loss: {ml}, at {en} epochs, with learning rate {lr}')
print(state_dict)