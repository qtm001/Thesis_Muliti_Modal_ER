import os
import pickle
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import torchvision.models as models
from torch.optim.lr_scheduler import StepLR
# from torchvision.models import resnet18, ResNet18_Weghts
# from torchvision.models import resnet50, ResNet50_Weights
### transformers --> BEATs, Wavlm
from BEATs.BEATs import BEATs, BEATsConfig



class Audio_Backbone(nn.Module):    #(batch_size, 512)
  ''' The feature extractor of audio, combined with Resnet18 and a fully connected layer'''
  def __init__(self, backbone_module, backbone_type, last_dim):
    super(Audio_Backbone, self).__init__()
    self.last_dim = last_dim
    self.backbone_module = backbone_module
    self.backbone = backbone_type
    if self.backbone == 'resnet':
      self.fc = nn.Linear((self.last_dim), 512)
    elif self.backbone == 'transformers':
      self.fc = nn.Linear((self.last_dim), 512) #(batch_size, 96, 768)
    # self.bn = nn.BatchNorm1d(512)
    # self.dp = nn.Dropout(p=0.5)
    # self.relu = nn.ReLU()

  def forward(self, x_audio):
    if self.backbone == 'resnet':
        x = self.backbone_module(x_audio)
        # print(x.shape)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
    elif self.backbone == 'transformers':
        x = self.backbone_module.extract_features(x_audio, padding_mask=None)[0]
        # x = x.view(x.size(0), -1)
        x = x[:, 0, :]
        # print(x.shape)
        # x = self.backbone_module(x_audio)
        x = self.fc(x)
        # x = self.bn(x)
        # x = self.relu(x)
        # x = self.dp(x)
        # print(x.shape)

    return x


class Predictor(nn.Module):
  ''' Emotion prediction Model'''
  def __init__(self, num_context_features):
    super(Predictor,self).__init__()
    self.num_context_features = num_context_features
    self.fc1 = nn.Linear((self.num_context_features), 256)
    self.bn1 = nn.BatchNorm1d(256)
    self.d1 = nn.Dropout(p=0.5)
    self.fc2 = nn.Linear(256, 128)
    self.bn2 = nn.BatchNorm1d(128)
    self.fc_out = nn.Linear(128, 2)
    self.relu = nn.ReLU()
    self.sigmoid = nn.Sigmoid()

  def forward(self, x_context):
    x_features = x_context.view(-1, self.num_context_features)
    x_out = self.fc1(x_features)
    x_out = self.bn1(x_out)
    x_out = self.relu(x_out)
    x_out = self.d1(x_out)
    x_out = self.fc2(x_out)
    x_out = self.bn2(x_out)
    x_out = self.relu(x_out)
    # x_out = self.d1(x_out)
    x_out = self.fc_out(x_out)
    va_out = self.sigmoid(x_out)
    return va_out

class Emotic_PreDataset(Dataset):
  ''' Custom Emotic dataset class. Use preprocessed data stored in npy files. '''
  def __init__(self, id_list, x_context, y_cont, transform=None):#, context_norm):
    super(Emotic_PreDataset,self).__init__()
    self.id_list = id_list
    self.x_context = x_context
    self.y_cont = y_cont
    self.y_valance = y_cont[:, 0]
    self.y_arousal = y_cont[:, 1]
    self.transform = transform
    # self.mean = np.mean(x_context, axis=0)
    # self.std = np.std(x_context, axis=0)

    # self.context_norm = transforms.Normalize(context_norm[0], context_norm[1])  # Normalizing the context image with context mean and context std

  def __len__(self):
    return len(self.y_valance)

  def __getitem__(self, index):
    id = self.id_list[index]
    audio_context = self.x_context[id]
    cont_label = self.y_cont[index]
    val_label = self.y_valance[index]
    aro_label = self.y_arousal[index]
    # audio_context = (audio_context - self.mean) / self.std
    return audio_context, torch.tensor(cont_label, dtype=torch.float32), id

class Audio_Dataset(Dataset):
  ''' Custom Emotic dataset class. Use preprocessed data stored in npy files. '''
  def __init__(self, id_list, x_context, y_cont, audio_dict, transform, backbone_type='resnet'):#, context_norm):
    super(Audio_Dataset,self).__init__()
    self.id_list = id_list
    self.x_context = x_context
    self.y_cont = y_cont
    self.audio_dict = audio_dict
    # self.y_valance = y_cont[:, 0]
    # self.y_arousal = y_cont[:, 1]
    self.transform = transform
    self.backbone_type = backbone_type
    # self.mean = np.mean(x_context, axis=0)
    # self.std = np.std(x_context, axis=0)

    # self.context_norm = transforms.Normalize(context_norm[0], context_norm[1])  # Normalizing the context image with context mean and context std

  def __len__(self):
    return len(self.y_cont)

  def __getitem__(self, index):
    id = self.id_list[index]
    if self.backbone_type == 'transformers':
        audio_context = self.x_context[id]
        # padding_mask = torch.zeros(audio_context.shape[0], audio_context.shape[1]).bool()
    elif self.backbone_type == 'resnet':
        audio_context = self.transform(self.x_context[self.audio_dict[id+'.wav']])
        # padding_mask = None
    cont_label = self.y_cont[index]
    # val_label = self.y_valance[index]
    # aro_label = self.y_arousal[index]
    # audio_context = (audio_context - self.mean) / self.std

    return audio_context, torch.tensor(cont_label, dtype=torch.float32), id #, torch.tensor(val_label, dtype=torch.float32), torch.tensor(aro_label, dtype=torch.float32), id

def extract_data_labels(data_path, data_type):
    audio_names = []

    audio_va_list = []

    with open(os.path.join(data_path, f'{data_type}_scale.txt'), 'r') as f:
      for line in f:
          audio_name, _, _, audio_va, _ = line.strip().split()
          audio_names.append(audio_name)
          audio_va_list.append(list(map(float, audio_va.split(','))))
    return audio_names, audio_va_list


def extract_data(data_path, data_type, backbone_type):
    with open(os.path.join(data_path, f'{data_type}_audio_dict.pkl'), 'rb') as fp:
        audio_dict = pickle.load(fp)
    if backbone_type == 'resnet':
        audio_context = np.load(os.path.join(data_path, f'{data_type}_audio_context.npy'))
    elif backbone_type == 'transformers':
        audio_context = torch.load(os.path.join(data_path, f'transformer_data/{data_type}_audio_dict.pt'))
    return audio_dict, audio_context

def train_dataload(args):
    data_dir = args.data_dir
    backbone_type = args.backbone
    train_audio, train_ava = extract_data_labels(data_dir, 'train')
    val_audio, val_ava = extract_data_labels(data_dir, 'val')

    # print(train_ava)

    train_audio_dict, train_audio_context = extract_data(data_dir, 'train', backbone_type)
    val_audio_dict, val_audio_context = extract_data(data_dir, 'val', backbone_type)

    batch_size = args.batch_size

    audio_transform = transforms.Compose([
                                        transforms.ToTensor()])

    train_dataset = Audio_Dataset(id_list=train_audio, x_context=train_audio_context, y_cont=train_ava, audio_dict=train_audio_dict, \
                                  transform=audio_transform, backbone_type=backbone_type)
    val_dataset = Audio_Dataset(id_list=val_audio, x_context=val_audio_context, y_cont=val_ava, audio_dict=val_audio_dict, \
                                  transform=audio_transform, backbone_type=backbone_type)

    train_loader = DataLoader(train_dataset, batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size, shuffle=False)

    return train_loader, val_loader

def test_dataset_load(args):
    data_dir = args.data_dir
    backbone_type = args.backbone
    test_audio, test_ava = extract_data_labels(data_dir, 'test')
    test_audio_dict, test_audio_context = extract_data(data_dir, 'test', backbone_type)
    # train_audio, train_ava = extract_data_labels(data_dir, 'train')
    # train_audio_dict, train_audio_context = extract_data(data_dir, 'train', backbone_type)
    audio_transform = transforms.Compose([
                                        transforms.ToTensor()])
    test_dataset = Audio_Dataset(id_list=test_audio, x_context=test_audio_context, y_cont=test_ava, audio_dict=test_audio_dict, \
                                  transform=audio_transform, backbone_type=backbone_type)
    # test_dataset = Audio_Dataset(id_list=train_audio, x_context=train_audio_context, y_cont=train_ava, audio_dict=train_audio_dict, \
    #                               transform=audio_transform, backbone_type=backbone_type)
    
    batch_size = args.batch_size
    test_loader = DataLoader(test_dataset, batch_size, shuffle=False)
    num_pirs = test_dataset.__len__()
    return test_loader, num_pirs

def model_loader(args):
    model_path = args.model_dir
    if args.resume == False:
      if args.backbone == 'resnet':
        model_audio = resnet50(weights=ResNet18_Weights.IMAGENET1K_V1)
        out_dim = list(model_audio.children())[-1].in_features
        model_audio = nn.Sequential(*(list(model_audio.children())[:-1]))
      elif args.backbone == 'transformers':
        checkpoint = torch.load('/mnt/data2/tianming_data/trans_models/BEATs_iter3_plus_AS2M_finetuned_on_AS2M_cpt2.pt')
        cfg = BEATsConfig(checkpoint['cfg'])
        model_audio = BEATs(cfg)
        model_audio.load_state_dict(checkpoint['model'])
        out_dim = list(model_audio.children())[-1].in_features

      audio_model = Audio_Backbone(model_audio, args.backbone, out_dim)
      single_modal = Predictor(audio_model.fc.out_features)

      if args.optimizer == 'sgd':
        opt = optim.SGD((list(single_modal.parameters()) + list(audio_model.parameters())), lr=1e-3, weight_decay=5e-4, momentum=0.9)
      elif args.optimizer == 'adam':
        opt = optim.Adam((list(single_modal.parameters()) + list(audio_model.parameters())), lr=1e-3, weight_decay=5e-4)
      
      scheduler = StepLR(opt, step_size=10, gamma=0.1)
      state_dict = {}
      state_dict['epoch_num'] = 0
      state_dict['min_loss'] = np.inf
      state_dict['min_loss_epochs'] = 0
      state_dict['optimizer'] = type(opt).__name__
      state_dict['learning_rate'] = opt.state_dict()['param_groups'][0]['lr']
      state_dict['batch_size'] = args.batch_size
      loss_dict = {}
      loss_dict['train_loss'] = []
      loss_dict['val_loss'] = []
      with open(os.path.join(model_path,f'model_state_dict_{type(opt).__name__}.pkl'), 'wb') as fp:
        pickle.dump(state_dict, fp)
      with open(os.path.join(model_path,f'loss_dict_{type(opt).__name__}.pkl'), 'wb') as fp:
        pickle.dump(loss_dict, fp)
    else:
      with open(os.path.join(model_path, 'model_state_dict.pkl'), 'rb') as fp:
        state_dict = pickle.load(fp)
      with open(os.path.join(model_path, 'loss_dict.pkl'), 'rb') as fp:
        loss_dict = pickle.load(fp)
      optimizer = args.optimizer
      audio_model = torch.load(os.path.join(model_path, f'model_audio_{optimizer}_normloss.pth'))
      single_modal = torch.load(os.path.join(model_path, f'model_single_modal_{optimizer}_normloss.pth'))
      if optimizer == 'SGD':
          opt = optim.SGD((list(single_modal.parameters()) + list(audio_model.parameters())), lr=1e-3, weight_decay=5e-4, momentum=0.9)
      elif optimizer == 'Adam':
          opt = optim.Adam((list(single_modal.parameters()) + list(audio_model.parameters())), lr=state_dict['learning_rate'], weight_decay=5e-4)
      scheduler = StepLR(opt, step_size=10, gamma=0.1)
    return audio_model, single_modal, state_dict, loss_dict, opt, scheduler
    
  