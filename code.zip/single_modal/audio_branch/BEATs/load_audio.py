import torchaudio
import torchaudio.compliance.kaldi as ta_kaldi
import torch


waveform, sample_rate = torchaudio.load('/mnt/data2/tianming_data/data/audio/81-13.wav')
fbank = ta_kaldi.fbank(waveform, num_mel_bins=128, sample_frequency=sample_rate, frame_length=25, frame_shift=10)
# fbank = torch.stack(fbank, dim=0)
print(waveform.shape)
print(sample_rate)
print(fbank.shape)