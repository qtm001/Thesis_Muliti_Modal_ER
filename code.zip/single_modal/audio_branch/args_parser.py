import os
import torch
import argparse

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', type=str, required=True, help='Path to image and labels')
    parser.add_argument('--model_dir', type=str, default='models', help='Directory name in which trained model will be stored')
    parser.add_argument('--result_dir', type=str, default='results', help='Directory name in which the test reuslts will be stored')
    parser.add_argument('--debug_mode', action='store_true', help='Debug mode. Will only save a small subset of the data')
    parser.add_argument('--batch_size', type=int, default=128, help='the batch size of dataloader')
    parser.add_argument('--optimizer', type=str, default='sgd', help='the optimizer of the training function')
    parser.add_argument('--epoch_num', type=int, default=100, help='the number of epochs')
    parser.add_argument('--backbone', type=str, default='resnet', help='the encoder type', choices=['resnet', 'transformers'])
    parser.add_argument('--resume', action='store_true', help='resume training')
    parser.add_argument('--fine_tune', action='store_true', help='fine-tune encoder or not')
    # parser.add_argument('--resume_path', type=str, default=None, help='the model of resume training path, will be consider when resume is true')
    # Generate args
    args = parser.parse_args()
    return args