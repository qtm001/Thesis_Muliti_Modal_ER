import numpy as np
import os
import scipy
from tqdm import tqdm
from utils import test_dataset_load, Emotic_PreDataset
import args_parser
import pickle

from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import torch



def test_mae(cont_preds, cont_labels):
  mae = np.zeros(1, dtype=np.float32)
  mae = np.mean(np.abs(cont_preds - cont_labels))
  print ('MAE', mae.mean())

  return mae.mean()

def test_mse(cont_preds, cont_labels):
  mse = np.zeros(1, dtype=np.float32)
  mse = np.mean(np.square(cont_preds - cont_labels))
  print ('MSE', mse.mean())

  return mse.mean()


args = args_parser.parse_args()
model_path = args.model_dir
backbone_type = args.backbone
result_path = args.result_dir
data_src = args.data_dir
batch_size = args.batch_size

# test_loader, num_audios = test_dataset_load(args)

test_context  = torch.load(os.path.join(data_src, f'transformer_data/test_content_dict_small.pt'))
test_cont = np.load(os.path.join(data_src, 'audio_test_data','test_cont_scale.npy'))
test_id = pd.read_csv(os.path.join(data_src, 'audio_test_data','test_scale.csv'))['Filename'].tolist()

train_transform = transforms.Compose([
                                      transforms.ToTensor()])
test_transform = transforms.Compose([
                                     transforms.ToTensor()])
test_dataset = Emotic_PreDataset(test_id, test_context, test_cont, \
                                 test_transform)
test_loader = DataLoader(test_dataset, batch_size, shuffle=False)

num_audios = test_dataset.__len__()

audio_model = torch.load(os.path.join(model_path, 'audio_BEATs_v2_finetune.pth'))
predictor = torch.load(os.path.join(model_path, 'predictor_BEATs_v2_finetune.pth'))
with open(os.path.join(model_path, 'model_state_dict_v2.pkl'), 'rb') as fp:
        state_dict = pickle.load(fp)
minloss = state_dict['min_loss']
minloss_epoch = state_dict['min_loss_epochs']
print(f'Start test, test with min val loss {minloss} at {minloss_epoch} epochs')
device = torch.device("cuda:2")
clips_id = []
val_preds = np.zeros(num_audios)
aro_preds = np.zeros(num_audios)
val_labels = np.zeros(num_audios)
aro_labels = np.zeros(num_audios)

with torch.no_grad():
    audio_model.to(device)
    predictor.to(device)
    audio_model.eval()
    predictor.eval()
    indx = 0
    # print ('starting testing')
    for audio_context, va_label, id in tqdm(iter(test_loader)):
        audio_context = audio_context.to(device)
        # print(audio_context.shape)

        pred_context = audio_model(audio_context)
        # print(pred_context.shape)
        pred_cont = predictor(pred_context)

        pred_cont_np = pred_cont.to("cpu").data.numpy()
        # print(f'id:{id}')
        # print(f'id[0]:{id[0]}')
        val_preds[ indx : (indx + pred_cont_np.shape[0])] = pred_cont_np[:, 0]
        aro_preds[ indx : (indx + pred_cont_np.shape[0])] = pred_cont_np[:, 1]
        val_labels[ indx : (indx + va_label.shape[0])] = va_label[:, 0].to("cpu").data.numpy()
        aro_labels[ indx : (indx + va_label.shape[0])] = va_label[:, 1].to("cpu").data.numpy()
        clips_id[ indx : (indx + va_label.shape[0])] = id
        indx = indx + pred_cont_np.shape[0]
        # print(indx)

val_preds = val_preds.transpose()
aro_preds = aro_preds.transpose()
val_labels = val_labels.transpose()
aro_labels = aro_labels.transpose()
scipy.io.savemat(os.path.join(result_path, f'valance_preds_newv2.mat'),mdict={'id':clips_id, 'cont_preds':val_preds})
scipy.io.savemat(os.path.join(result_path, f'arousal_preds_newv2.mat'),mdict={'id':clips_id, 'cont_preds':aro_preds})
scipy.io.savemat(os.path.join(result_path, f'valance_labels_newv2.mat'),mdict={'id':clips_id, 'cont_labels':val_labels})
scipy.io.savemat(os.path.join(result_path, f'arousal_labels_newv2.mat'),mdict={'id':clips_id, 'cont_labels':aro_labels})

print ('completed testing')
print ('evaluate on valance')
val_mean_mae = test_mae(val_preds, val_labels)
val_mean_mse = test_mse(val_preds, val_labels)

print ('evaluate on arousal')
aro_mean_mae = test_mae(aro_preds, aro_labels)
aro_mean_mse = test_mse(aro_preds, aro_labels)
