from utils import train_dataload, model_loader
import os
import pickle
import numpy as np
import args_parser
from tqdm import tqdm
import matplotlib.pyplot as plt

import torch
from transformers import AutoImageProcessor

args = args_parser.parse_args()
backbone_type = args.backbone
train_loader, val_loader = train_dataload(args)
image_processor = AutoImageProcessor.from_pretrained("google/vit-base-patch16-224")
image_model, single_modal, state_dict, loss_dict, opt, scheduler = model_loader(args)
print(f'Finish load data, train loader: {len(train_loader)}, val loader: {len(val_loader)}, with batch size {val_loader.batch_size}')

if args.fine_tune:
  for param in image_model.parameters():
    param.requires_grad = True
else:
  for param in image_model.parameters():
    param.requires_grad = False
  for param in image_model.fc.parameters():
    param.requires_grad = True
for param in single_modal.parameters():
  param.requires_grad = True

device = torch.device("cuda:3")
epoch_nums = args.epoch_num

loss_mse = torch.nn.MSELoss(size_average=None, reduce=None, reduction= "mean")

optimizer = state_dict['optimizer']
model_path = args.model_dir
result_path = args.result_dir

if not os.path.exists(model_path):
    os.makedirs(model_path)
if not os.path.exists(result_path):
    os.makedirs(result_path)

min_loss = np.inf


print('start training')

for e in range(epoch_nums):
    running_loss = 0.0

    image_model.to(device)
    single_modal.to(device)

    image_model.train()
    single_modal.train()

    for audio_context, labels_cont, _ in tqdm(iter(train_loader)):
        audio_context = audio_context.to(device)
        labels_cont = labels_cont.to(device)
        # padding_mask = torch.zeros(audio_context.shape[1], audio_context.shape[2]).bool().to(device)
        # print(padding_mask.shape)
        # print(labels_cont)
        
        opt.zero_grad()
        pred_context = image_model(audio_context)
        # print(pred_context.shape)
        pred_cont= single_modal(pred_context)
        # print(f'pred:{pred_cont}, lable: {labels_cont}')
        loss_batch = loss_mse(pred_cont, labels_cont)
        loss = loss_batch
        running_loss += loss.item()
        loss.backward()
        opt.step()

    print ('epoch = %d training loss = %.4f' %(e, running_loss/len(train_loader)))
    loss_dict['train_loss'].append(running_loss/len(train_loader))


    running_loss = 0.0
    image_model.eval()
    single_modal.eval()

    with torch.no_grad():
        for audio_context, labels_cont, _ in iter(val_loader):

          audio_context = audio_context.to(device)
          labels_cont = labels_cont.to(device)

          pred_context = image_model(audio_context)
          pred_cont = single_modal(pred_context)

          cont_loss_batch = loss_mse(pred_cont, labels_cont)
          loss = cont_loss_batch
          # print(loss)
          running_loss += loss.item()

    print ('epoch = %d validation loss = %.4f' %(e, running_loss/len(val_loader)))
    loss_dict['val_loss'].append(running_loss/len(val_loader))

    scheduler.step()

    if loss_dict['val_loss'][-1] < min_loss:
        min_loss = loss_dict['val_loss'][-1]
        counter = 0

        # saving models for lowest loss
        print ('saving model at epoch e = %d' %(e))
        image_model.to("cpu")
        single_modal.to("cpu")
        torch.save(image_model, os.path.join(model_path, f'image_ViT_v2_finetune.pth'))
        torch.save(single_modal, os.path.join(model_path, f'predictor_ViT_v2_finetune.pth'))
    elif np.isnan(loss_dict['val_loss'][-1]):
        print('NAN LOSS !')
        break
f, (ax1, ax2) = plt.subplots(1, 2, figsize = (6, 6))
f.suptitle('audio predict')
ax1.plot(range(0,len(loss_dict['train_loss'])),loss_dict['train_loss'], color='Blue')
ax2.plot(range(0,len( loss_dict['val_loss'])), loss_dict['val_loss'], color='Red')
ax1.legend(['train'])
ax2.legend(['val'])
plt.savefig(os.path.join(result_path, 'train_valloss_v2_finetune.png'))


