import pickle
import os
import numpy as np

from transformers import AutoImageProcessor
import torch
from tqdm import tqdm


def extract_data_labels(data_path, data_type):
    image_names = []

    image_va_list = []

    with open(os.path.join(data_path, f'{data_type}_scale.txt'), 'r') as f:
      for line in f:
          _, image_name, _, _, image_va = line.strip().split()
          image_names.append(image_name)
          image_va_list.append(list(map(float, image_va.split(','))))
    return image_names, image_va_list


def extract_data(data_path, data_type, backbone_type):
    with open(os.path.join(data_path, f'{data_type}_image_dict.pkl'), 'rb') as fp:
        image_dict = pickle.load(fp)
    if backbone_type == 'resnet':
        image_context = np.load(os.path.join(data_path, f'{data_type}_image_context.npy'))
    elif backbone_type == 'transformers':
        image_context = np.load(os.path.join(data_path, f'{data_type}_image_context.npy'))
    return image_dict, image_context


image_processor = AutoImageProcessor.from_pretrained("google/vit-base-patch16-224")

data_t = ['train', 'val', 'test']
for t in data_t:
    image_dict_tensor = {}
    image_names, _ = extract_data_labels('/mnt/data2/tianming_data/data', t)
    image_dict, image_context = extract_data('/mnt/data2/tianming_data/data', t, 'transformers')
    for key, value in tqdm(image_dict.items()):
        image_dict_tensor[key] = image_processor(image_context[value], return_tensors="pt")['pixel_values']

    torch.save(image_dict_tensor, f"/mnt/data2/tianming_data/{t}_image_dict.pt")

