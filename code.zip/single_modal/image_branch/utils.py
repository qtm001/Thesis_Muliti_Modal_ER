import os
import pickle
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import torchvision.models as models
from torch.optim.lr_scheduler import StepLR
# from torchvision.models import resnet18, ResNet18_Weghts
# from torchvision.models import resnet50, ResNet50_Weights
### transformers --> BEATs, Wavlm, ViT
from transformers import AutoImageProcessor, ViTModel



class Image_Backbone(nn.Module):
  ''' The feature extractor of audio, combined with Resnet50 and a fully connected layer'''
  def __init__(self, backbone_module, backbone_type, last_dim):
    super(Image_Backbone, self).__init__()
    self.last_dim = last_dim
    self.backbone_module = backbone_module
    self.backbone = backbone_type
    if self.backbone == 'resnet':
      self.fc = nn.Linear((self.last_dim), 512)
    elif self.backbone == 'transformers':
      self.fc = nn.Linear((self.last_dim), 512)

  def forward(self, x_audio):
    # print(x_audio.shape)
    if self.backbone == 'resnet':
        x = self.backbone_module(x_audio)
        # print(x.shape)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
    elif self.backbone == 'transformers':
        x = self.backbone_module(x_audio).last_hidden_state
        # x = x.view(x.size(0), -1)
        x = x[:,0,:]
        # print(x.shape)
        # x = self.backbone_module(x_audio)
        x = self.fc(x)
        # print(x.shape)

    return x

class Predictor(nn.Module):
  ''' Emotion prediction Model'''
  def __init__(self, num_context_features):
    super(Predictor,self).__init__()
    self.num_context_features = num_context_features
    self.fc1 = nn.Linear((self.num_context_features), 256)
    self.bn1 = nn.BatchNorm1d(256)
    self.d1 = nn.Dropout(p=0.5)
    self.fc2 = nn.Linear(256, 128)
    self.bn2 = nn.BatchNorm1d(128)
    self.fc_out = nn.Linear(128, 2)
    self.relu = nn.ReLU()
    self.sigmoid = nn.Sigmoid()

  def forward(self, x_context):
    x_features = x_context.view(-1, self.num_context_features)
    x_out = self.fc1(x_features)
    x_out = self.bn1(x_out)
    x_out = self.relu(x_out)
    x_out = self.d1(x_out)
    x_out = self.fc2(x_out)
    x_out = self.bn2(x_out)
    x_out = self.relu(x_out)
    # x_out = self.d1(x_out)
    x_out = self.fc_out(x_out)
    va_out = self.sigmoid(x_out)
    return va_out
  
class Image_Dataset(Dataset):
  ''' Custom Emotic dataset class. Use preprocessed data stored in npy files. '''
  def __init__(self, id_list, x_context, y_cont, image_dict, transform, context_norm, backbone_type='resnet'):
    super(Image_Dataset,self).__init__()
    self.id_list = id_list
    self.x_context = x_context
    self.y_cont = y_cont
    self.image_dict = image_dict
    # self.y_valance = y_cont[:, 0]
    # self.y_arousal = y_cont[:, 1]
    self.transform = transform
    self.backbone_type = backbone_type
    self.context_norm = transforms.Normalize(context_norm[0], context_norm[1])  # Normalizing the context image with context mean and context std for resnet

  def __len__(self):
    return len(self.y_cont)

  def __getitem__(self, index):
    id = self.id_list[index]
    if self.backbone_type == 'transformers':              
        image_context = self.x_context[id +'.jpg'].squeeze()     # output should be [3, 224, 224]
        # print(image_context.shape)
        # padding_mask = torch.zeros(audio_context.shape[0], audio_context.shape[1]).bool()
    elif self.backbone_type == 'resnet':
        image_context = self.context_norm(self.transform(self.x_context[self.image_dict[id + '.jpg']]))
        # padding_mask = None
    cont_label = self.y_cont[index]
    # val_label = self.y_valance[index]
    # aro_label = self.y_arousal[index]
    # audio_context = (audio_context - self.mean) / self.std

    return image_context, torch.tensor(cont_label, dtype=torch.float32), id #, torch.tensor(val_label, dtype=torch.float32), torch.tensor(aro_label, dtype=torch.float32), id

def extract_data_labels(data_path, data_type):
    image_names = []

    image_va_list = []

    with open(os.path.join(data_path, f'{data_type}_scale.txt'), 'r') as f:
      for line in f:
          _, image_name, _, _, image_va = line.strip().split()
          image_names.append(image_name)
          image_va_list.append(list(map(float, image_va.split(','))))
    return image_names, image_va_list


def extract_data(data_path, data_type, backbone_type):
    with open(os.path.join(data_path, f'{data_type}_image_dict.pkl'), 'rb') as fp:
        image_dict = pickle.load(fp)
    if backbone_type == 'resnet':
        image_context = np.load(os.path.join(data_path, f'{data_type}_image_context.npy'))
    elif backbone_type == 'transformers':
        image_context = torch.load(os.path.join(data_path, f'transformer_data/{data_type}_image_dict.pt'))
    return image_dict, image_context

def train_dataload(args):
    data_dir = args.data_dir
    backbone_type = args.backbone
    train_image, train_ava = extract_data_labels(data_dir, 'train')
    val_image, val_ava = extract_data_labels(data_dir, 'val')

    # print(train_ava)
    context_mean = [0.4690646, 0.4407227, 0.40508908]
    context_std = [0.2514227, 0.24312855, 0.24266963]
    context_norm = [context_mean, context_std]
    train_image_dict, train_image_context = extract_data(data_dir, 'train', backbone_type)
    val_image_dict, val_image_context = extract_data(data_dir, 'val', backbone_type)
    batch_size = args.batch_size

    train_transform = transforms.Compose([transforms.ToPILImage(),
                                          transforms.RandomHorizontalFlip(),
                                          transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4),
                                          transforms.ToTensor()])

    train_dataset = Image_Dataset(id_list=train_image, x_context=train_image_context, y_cont=train_ava, image_dict=train_image_dict, \
                                  transform=train_transform, context_norm=context_norm, backbone_type=backbone_type)
    val_dataset = Image_Dataset(id_list=val_image, x_context=val_image_context, y_cont=val_ava, image_dict=val_image_dict, \
                                  transform=train_transform, context_norm=context_norm, backbone_type=backbone_type)

    train_loader = DataLoader(train_dataset, batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size, shuffle=False)

    return train_loader, val_loader

def test_dataset_load(args):
    data_dir = args.data_dir
    backbone_type = args.backbone
    test_image, test_ava = extract_data_labels(data_dir, 'test')
    test_image_dict, test_image_context = extract_data(data_dir, 'test', backbone_type)
    context_mean = [0.4690646, 0.4407227, 0.40508908]
    context_std = [0.2514227, 0.24312855, 0.24266963]
    context_norm = [context_mean, context_std]
    test_transform = transforms.Compose([transforms.ToPILImage(),
                                        transforms.ToTensor()])
    test_dataset = Image_Dataset(id_list=test_image, x_context=test_image_context, y_cont=test_ava, image_dict=test_image_dict, \
                                  transform=test_transform, context_norm=context_norm, backbone_type=backbone_type)
    
    batch_size = args.batch_size
    test_loader = DataLoader(test_dataset, batch_size, shuffle=False)
    num_pirs = test_dataset.__len__()
    return test_loader, num_pirs

def model_loader(args):
    model_path = args.model_dir
    if args.resume == False:
      if args.backbone == 'resnet':
        image_model = resnet50(weights=ResNet50_Weights.IMAGENET1K_V1)
        out_dim = list(image_model.children())[-1].in_features
        model_image = nn.Sequential(*(list(image_model.children())[:-1]))
      elif args.backbone == 'transformers':
        model_image = ViTModel.from_pretrained("google/vit-base-patch16-224-in21k")
        out_dim = model_image.pooler.dense.out_features

      image_model = Image_Backbone(model_image, args.backbone, out_dim)
      single_modal = Predictor(list(image_model.children())[-1].out_features)

      if args.optimizer == 'sgd':
        opt = optim.SGD((list(single_modal.parameters()) + list(image_model.parameters())), lr=1e-3, weight_decay=5e-4, momentum=0.9)
      elif args.optimizer == 'adam':
        opt = optim.Adam((list(single_modal.parameters()) + list(image_model.parameters())), lr=1e-3, weight_decay=5e-4)
      
      scheduler = StepLR(opt, step_size=10, gamma=0.1)
      state_dict = {}
      state_dict['epoch_num'] = 0
      state_dict['min_loss'] = np.inf
      state_dict['min_loss_epochs'] = 0
      state_dict['optimizer'] = type(opt).__name__
      state_dict['learning_rate'] = opt.state_dict()['param_groups'][0]['lr']
      state_dict['batch_size'] = args.batch_size
      loss_dict = {}
      loss_dict['train_loss'] = []
      loss_dict['val_loss'] = []
      with open(os.path.join(model_path,'model_state_dict_v2.pkl'), 'wb') as fp:
        pickle.dump(state_dict, fp)
      with open(os.path.join(model_path,'loss_dict_v2.pkl'), 'wb') as fp:
        pickle.dump(loss_dict, fp)
    else:
      with open(os.path.join(model_path, 'model_state_dict_image.pkl'), 'rb') as fp:
        state_dict = pickle.load(fp)
      with open(os.path.join(model_path, 'loss_dict.pkl'), 'rb') as fp:
        loss_dict = pickle.load(fp)
      optimizer = args.optimizer
      image_model = torch.load(os.path.join(model_path, f'model_image_{optimizer}_ViT.pth'))
      single_modal = torch.load(os.path.join(model_path, f'model_single_modal_{optimizer}_ViT.pth'))
      if optimizer == 'SGD':
          opt = optim.SGD((list(single_modal.parameters()) + list(image_model.parameters())), lr=state_dict['learning_rate'], weight_decay=5e-4, momentum=0.9)
      elif optimizer == 'Adam':
          opt = optim.Adam((list(single_modal.parameters()) + list(image_model.parameters())), lr=state_dict['learning_rate'], weight_decay=5e-4)
      scheduler = StepLR(opt, step_size=20, gamma=0.1)
    return image_model, single_modal, state_dict, loss_dict, opt, scheduler
    
  