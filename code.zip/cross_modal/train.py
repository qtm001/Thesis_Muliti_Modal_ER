import os
import pickle
import numpy as np
import args_parser
from tqdm import tqdm
import matplotlib.pyplot as plt
from module import Image_Backbone, Audio_Backbone, SMmodel, CMmodel
from utils.util import load_models
from losses import cfrLoss, cfmLoss, sfrLoss
from dataset_loader import train_dataset_load

import torch
import torch.nn as nn 
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR
from torchvision.models import resnet18, ResNet18_Weights
from torchvision.models import resnet50, ResNet50_Weights

### Transformers encoder -> Vit, BEATs, Wavlm
from transformers import AutoImageProcessor, ViTModel
from utils.BEATs.BEATs import BEATs, BEATsConfig

args = args_parser.parse_args()
train_dataloader, val_dataloader = train_dataset_load(args)
print(f'Finish load data, train loader: {len(train_dataloader)}, val loader: {len(val_dataloader)}, with batch size {train_dataloader.batch_size}')

model_path = args.model_dir
results_path = args.result_dir
backbone_type = args.backbone
num_layers = args.encoder_layers

if not os.path.exists(model_path):
    os.makedirs(model_path)
if not os.path.exists(results_path):
    os.makedirs(results_path)

### model setting
if args.resume == False:
    if backbone_type == 'resnet':
      image_model = resnet50(weights=ResNet50_Weights.IMAGENET1K_V2)
      last_dim_image = list(image_model.children())[-1].in_features
      model_image = nn.Sequential(*(list(image_model.children())[:-1]))
      model_audio = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)
      last_dim_audio = list(image_model.children())[-1].in_features
      model_audio = nn.Sequential(*(list(model_audio.children())[:-1]))
    elif backbone_type == 'transformers':
      # ViT image
      model_image = ViTModel.from_pretrained("google/vit-base-patch16-224-in21k")
      last_dim_image = model_image.pooler.dense.out_features
      # BEATs audio
      checkpoint = torch.load('/mnt/data2/tianming_data/trans_models/BEATs_iter3_plus_AS2M_finetuned_on_AS2M_cpt2.pt')
      cfg = BEATsConfig(checkpoint['cfg'])
      model_audio = BEATs(cfg)
      model_audio.load_state_dict(checkpoint['model'])
      last_dim_audio = list(model_audio.children())[-1].in_features
  
    image_backbone = Image_Backbone(model_image, last_dim_image, args)
    audio_backbone = Audio_Backbone(model_audio, last_dim_audio, args)


    cross_modal_model = CMmodel(list(image_backbone.children())[-1].out_features , list(audio_backbone.children())[-1].out_features)
    single_modal_model = SMmodel(list(image_backbone.children())[-1].out_features)

    if args.optimizer == 'sgd':
      opt = optim.SGD((list(cross_modal_model.parameters()) + list(single_modal_model.parameters()) \
                    + list(image_backbone.parameters()) + list(audio_backbone.parameters())), lr=1e-3, weight_decay=5e-4, momentum=0.9)
    elif args.optimizer == 'adam':
      opt = optim.Adam((list(cross_modal_model.parameters()) + list(single_modal_model.parameters()) \
                    + list(image_backbone.parameters()) + list(audio_backbone.parameters())), lr=1e-3, weight_decay=5e-4) 
    scheduler = StepLR(opt, step_size=10, gamma=0.1)
    model_state_dict = {}
    model_state_dict['epoch_num'] = 0
    model_state_dict['min_loss'] = np.inf
    model_state_dict['min_loss_epochs'] = 0
    model_state_dict['optimizer'] = type(opt).__name__
    model_state_dict['learning_rate'] = opt.state_dict()['param_groups'][0]['lr']
    model_state_dict['batch_size'] = train_dataloader.batch_size
    with open(os.path.join(model_path,'model_state_dict.pkl'), 'wb') as fp:
      pickle.dump(model_state_dict, fp)
    loss_dict = {}
    loss_dict['cfr_loss'] = [0, 0, [], []]   #[first_batch_train_loss, first_batch_val_loss, [loss_of_each_epoch_train], [loss_of_each_epoch_val]]
    loss_dict['cfm_loss'] = [0, 0, [], []]
    loss_dict['sfri_loss'] = [0, 0, [], []]
    loss_dict['sfra_loss'] = [0, 0, [], []]
    loss_dict['sim_mseloss'] = [0, 0, [], []]
    loss_dict['image_mseloss'] = [0, 0, [], []]
    loss_dict['audio_mseloss'] = [0, 0, [], []]
    loss_dict['tot_loss'] = []
    loss_dict['val_loss'] = []
    with open(os.path.join(model_path,'training_loss_dict.pkl'), 'wb') as fp:
      pickle.dump(loss_dict, fp)
else:
    image_backbone, audio_backbone, single_modal_model, cross_modal_model, model_state_dict, loss_dict, opt, scheduler = load_models(args)
    ml = model_state_dict['min_loss']
    en = model_state_dict['min_loss_epochs']
    lr = model_state_dict['learning_rate']
    print(f'resume training, with the min val loss: {ml}, at {en} epochs, with learning rate {lr}')

# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
device = torch.device("cuda:0")
print(device)

loss_mse = torch.nn.MSELoss(size_average=None, reduce=None, reduction= "mean")
loss_cfr = cfrLoss(2)
loss_cfm = cfmLoss(15) #if backbone_type == 'resnet' else cfmLoss(8.5)
loss_sfr = sfrLoss(2)

counter = 0

train_loss = list()
val_loss = list()

epoch_num = args.epoch_num

print('start training')

for e in range(epoch_num):
  model_state_dict['epoch_num'] = model_state_dict['epoch_num'] + 1
  running_loss = 0.0

  image_backbone.to(device)
  audio_backbone.to(device)
  cross_modal_model.to(device)
  single_modal_model.to(device)

  image_backbone.train()
  audio_backbone.train()
  cross_modal_model.train()
  single_modal_model.train()

  cfr_loss_epoch = 0
  cfm_loss_epoch = 0
  sfri_loss_epoch = 0
  sfra_loss_epoch = 0
  sim_mseloss_epoch = 0
  image_mseloss_epoch = 0
  audio_mseloss_epoch = 0 

  for images_context, audio_context, similarity_score, image_va, audio_va, image_cfr, image_audio_sim, audio_cfr, audio_image_sim, \
  image_n1, image_n2, image_va1, image_va2, audio_n1, audio_n2, audio_va1, audio_va2 in tqdm(iter(train_dataloader)):

      images_context = images_context.to(device)
      audio_context = audio_context.to(device)
      similarity_score = similarity_score.unsqueeze(1).to(device)
      image_va = image_va.to(device)
      audio_va = audio_va.to(device)

      image_cfr = image_cfr.to(device)
      image_audio_sim = image_audio_sim.unsqueeze(1).to(device)
      audio_cfr = audio_cfr.to(device)
      audio_image_sim = audio_image_sim.unsqueeze(1).to(device)
      image_n1 = image_n1.to(device)
      image_n2 = image_n2.to(device)
      image_va1 = image_va1.to(device)
      image_va2 = image_va2.to(device)
      audio_n1 = audio_n1.to(device)
      audio_n2 = audio_n2.to(device)
      audio_va1 = audio_va1.to(device)
      audio_va2 = audio_va2.to(device)
      

      ## sim loss
      # print(images_context.shape)
      pred_image_context = image_backbone(images_context)
      # print(pred_image_context[0])
      if backbone_type == 'resnet':
        audio_backbone = audio_backbone.float()
        pred_audio_context = audio_backbone(audio_context.float())
        audio_cfr_context = audio_backbone(audio_cfr.float())
        audio_n1_context = audio_backbone(audio_n1.float())
        audio_n2_context = audio_backbone(audio_n2.float())
      elif backbone_type == 'transformers':
        pred_audio_context = audio_backbone(audio_context)
        audio_cfr_context = audio_backbone(audio_cfr)
        audio_n1_context = audio_backbone(audio_n1)
        audio_n2_context = audio_backbone(audio_n2)
      # print(pred_audio_context[0])
      pred_sim = cross_modal_model(pred_image_context, pred_audio_context)
      pred_image_va = single_modal_model(pred_image_context)
      pred_audio_va = single_modal_model(pred_audio_context)

      ## cfr loss
      image_cfr_context = image_backbone(image_cfr)
      
      ## sfr loss
      image_n1_context = image_backbone(image_n1)
      image_n2_context = image_backbone(image_n2)

      sfr_image = [image_n1_context, image_n2_context, image_va1, image_va2]
      sfr_audio = [audio_n1_context, audio_n2_context, audio_va1, audio_va2]
      cfr_data = [image_cfr_context, image_audio_sim, audio_cfr_context, audio_image_sim]

      cfr_loss_batch = loss_cfr.forward(pred_image_context, pred_audio_context, similarity_score, cfr_data)
      cfm_loss_batch = loss_cfm.forward(pred_image_context, pred_audio_context)
      sfri_loss_batch = loss_sfr.forward(image_cfr_context, image_va, sfr_image)
      sfra_loss_batch = loss_sfr.forward(audio_cfr_context, audio_va, sfr_audio)
      sim_mseloss_batch = loss_mse.forward(similarity_score, pred_sim)
      image_mseloss_batch = loss_mse.forward(image_va, pred_image_va)
      audio_mseloss_batch = loss_mse.forward(audio_va, pred_audio_va)

      if loss_dict['cfr_loss'][0] == 0:     # record the first batch loss
        loss_dict['cfr_loss'][0] = cfr_loss_batch.detach()
        loss_dict['sfri_loss'][0] = sfri_loss_batch.detach()
        loss_dict['sfra_loss'][0] = sfra_loss_batch.detach()
        loss_dict['sim_mseloss'][0] = sim_mseloss_batch.detach()
        loss_dict['image_mseloss'][0] = image_mseloss_batch.detach()
        loss_dict['audio_mseloss'][0] = audio_mseloss_batch.detach()

      if loss_dict['cfm_loss'][0] == 0:     # record cfm loss since cfm is always = 0
        loss_dict['cfm_loss'][0] = cfm_loss_batch.detach()

      cfr_loss_norm = torch.div(cfr_loss_batch, loss_dict['cfr_loss'][0])
      cfm_loss_norm = torch.div(cfm_loss_batch, loss_dict['cfr_loss'][0]) if loss_dict['cfr_loss'][0] != 0 else cfm_loss_batch
      sfri_loss_norm = torch.div(sfri_loss_batch, loss_dict['sfri_loss'][0])
      sfra_loss_norm = torch.div(sfra_loss_batch, loss_dict['sfra_loss'][0])
      sim_mseloss_norm = torch.div(sim_mseloss_batch, loss_dict['sim_mseloss'][0])
      image_mseloss_norm = torch.div(image_mseloss_batch, loss_dict['image_mseloss'][0])
      audio_mseloss_norm = torch.div(audio_mseloss_batch, loss_dict['audio_mseloss'][0])


      cfr_loss_epoch += cfr_loss_norm.item()
      cfm_loss_epoch += cfm_loss_norm.item()
      sfri_loss_epoch += sfri_loss_norm.item()
      sfra_loss_epoch += sfra_loss_norm.item()
      sim_mseloss_epoch += sim_mseloss_norm.item()
      image_mseloss_epoch += image_mseloss_norm.item()
      audio_mseloss_epoch += audio_mseloss_norm.item()

      # print(f'cfr_loss_batch:{cfr_loss_norm.item()}, cfm_loss_batch:{cfm_loss_norm.item()}, sfri_loss_batch:{sfri_loss_norm.item()}, \
      #      sfra_loss_batch:{sfra_loss_norm.item()}, sim_mseloss_batch:{sim_mseloss_norm.item()}, image_mseloss_batch:{image_mseloss_norm.item()}, audio_mseloss_batch:{audio_mseloss_norm.item()}')
      loss = (cfr_loss_norm + cfm_loss_norm + sfri_loss_norm + sfra_loss_norm + \
              sim_mseloss_norm + image_mseloss_norm + audio_mseloss_norm) / 7
      running_loss += loss.item()
      opt.zero_grad()
      
      loss.backward()
      opt.step()

  loss_dict['cfr_loss'][2].append(cfr_loss_epoch/len(train_dataloader))
  loss_dict['cfm_loss'][2].append(cfm_loss_epoch/len(train_dataloader))
  loss_dict['sfri_loss'][2].append(sfri_loss_epoch/len(train_dataloader))
  loss_dict['sfra_loss'][2].append(sfra_loss_epoch/len(train_dataloader))
  loss_dict['sim_mseloss'][2].append(sim_mseloss_epoch/len(train_dataloader))
  loss_dict['image_mseloss'][2].append(image_mseloss_epoch/len(train_dataloader))
  loss_dict['audio_mseloss'][2].append(audio_mseloss_epoch/len(train_dataloader))
  loss_dict['tot_loss'].append(running_loss/len(train_dataloader))
  print ('epoch = %d training loss = %.4f' %(model_state_dict['epoch_num'], running_loss/len(train_dataloader)))
  train_loss.append(running_loss/len(train_dataloader))

  running_loss = 0.0
  image_backbone.eval()
  audio_backbone.eval()
  cross_modal_model.eval()
  single_modal_model.eval()

  with torch.no_grad():
      cfr_loss_epoch = 0
      cfm_loss_epoch = 0
      sfri_loss_epoch = 0
      sfra_loss_epoch = 0
      sim_mseloss_epoch = 0
      image_mseloss_epoch = 0
      audio_mseloss_epoch = 0 
      for images_context, audio_context, similarity_score, image_va, audio_va, image_cfr, image_audio_sim, audio_cfr, audio_image_sim,\
          image_n1, image_n2, image_va1, image_va2, audio_n1, audio_n2, audio_va1, audio_va2 in tqdm(iter(val_dataloader)):
        images_context = images_context.to(device)
        audio_context = audio_context.to(device)
        similarity_score = similarity_score.unsqueeze(1).to(device)
        image_va = image_va.to(device)
        audio_va = audio_va.to(device)

        image_cfr = image_cfr.to(device)
        image_audio_sim = image_audio_sim.unsqueeze(1).to(device)
        audio_cfr = audio_cfr.to(device)
        audio_image_sim = audio_image_sim.unsqueeze(1).to(device)

        image_n1 = image_n1.to(device)
        image_n2 = image_n2.to(device)
        image_va1 = image_va1.to(device)
        image_va2 = image_va2.to(device)

        audio_n1 = audio_n1.to(device)
        audio_n2 = audio_n2.to(device)
        audio_va1 = audio_va1.to(device)
        audio_va2 = audio_va2.to(device)

        pred_image_context = image_backbone(images_context)
        if backbone_type == 'resnet':
          audio_backbone = audio_backbone.float()
          pred_audio_context = audio_backbone(audio_context.float())
          audio_cfr_context = audio_backbone(audio_cfr.float())
          audio_n1_context = audio_backbone(audio_n1.float())
          audio_n2_context = audio_backbone(audio_n2.float())
        elif backbone_type == 'transformers':
          pred_audio_context = audio_backbone(audio_context)
          audio_cfr_context = audio_backbone(audio_cfr)
          audio_n1_context = audio_backbone(audio_n1)
          audio_n2_context = audio_backbone(audio_n2)

        pred_sim = cross_modal_model(pred_image_context, pred_audio_context)
        pred_image_va = single_modal_model(pred_image_context)
        pred_audio_va = single_modal_model(pred_audio_context)
        ## cfr loss
        image_cfr_context = image_backbone(image_cfr)
        ## sfr loss
        image_n1_context = image_backbone(image_n1)
        image_n2_context = image_backbone(image_n2)

        sfr_image = [image_n1_context, image_n2_context, image_va1, image_va2]
        sfr_audio = [audio_n1_context, audio_n2_context, audio_va1, audio_va2]
        cfr_data = [image_cfr_context, image_audio_sim, audio_cfr_context, audio_image_sim]

        cfr_loss_batch = loss_cfr.forward(pred_image_context, pred_audio_context, similarity_score, cfr_data)
        cfm_loss_batch = loss_cfm.forward(pred_image_context, pred_audio_context)
        sfri_loss_batch = loss_sfr.forward(image_cfr_context, image_va, sfr_image)
        sfra_loss_batch = loss_sfr.forward(audio_cfr_context, audio_va, sfr_audio)
        sim_mseloss_batch = loss_mse.forward(pred_sim, similarity_score)
        image_mseloss_batch = loss_mse.forward(pred_image_va, image_va)
        audio_mseloss_batch = loss_mse.forward(pred_audio_va, audio_va)

        if loss_dict['cfr_loss'][1] == 0:     # record the first batch loss
          loss_dict['cfr_loss'][1] = cfr_loss_batch.detach()
          loss_dict['sfri_loss'][1] = sfri_loss_batch.detach()
          loss_dict['sfra_loss'][1] = sfra_loss_batch.detach()
          loss_dict['sim_mseloss'][1] = sim_mseloss_batch.detach()
          loss_dict['image_mseloss'][1] = image_mseloss_batch.detach()
          loss_dict['audio_mseloss'][1] = audio_mseloss_batch.detach()

        if loss_dict['cfm_loss'][1] == 0:     # record cfm loss since cfm is always = 0
          loss_dict['cfm_loss'][1] = cfm_loss_batch.detach()

        cfr_loss_norm = torch.div(cfr_loss_batch, loss_dict['cfr_loss'][1])
        cfm_loss_norm = torch.div(cfm_loss_batch, loss_dict['cfr_loss'][1]) if loss_dict['cfr_loss'][0] != 0 else cfm_loss_batch
        sfri_loss_norm = torch.div(sfri_loss_batch, loss_dict['sfri_loss'][1])
        sfra_loss_norm = torch.div(sfra_loss_batch, loss_dict['sfra_loss'][1])
        sim_mseloss_norm = torch.div(sim_mseloss_batch, loss_dict['sim_mseloss'][1])
        image_mseloss_norm = torch.div(image_mseloss_batch, loss_dict['image_mseloss'][1])
        audio_mseloss_norm = torch.div(audio_mseloss_batch, loss_dict['audio_mseloss'][1])

        # print(f'cfr_loss_batch:{cfr_loss_norm.item()}, cfm_loss_batch:{cfm_loss_norm.item()}, sfri_loss_batch:{sfri_loss_norm.item()}, \
          #  sfra_loss_batch:{sfra_loss_norm.item()}, sim_mseloss_batch:{sim_mseloss_norm.item()}, image_mseloss_batch:{image_mseloss_norm.item()}, audio_mseloss_batch:{audio_mseloss_norm.item()}')
        cfr_loss_epoch += cfr_loss_norm.item()
        cfm_loss_epoch += cfm_loss_norm.item()
        sfri_loss_epoch += sfri_loss_norm.item()
        sfra_loss_epoch += sfra_loss_norm.item()
        sim_mseloss_epoch += sim_mseloss_norm.item()
        image_mseloss_epoch += image_mseloss_norm.item()
        audio_mseloss_epoch += audio_mseloss_norm.item()
        loss = (cfr_loss_norm + cfm_loss_norm + sfri_loss_norm + sfra_loss_norm + \
                sim_mseloss_norm + image_mseloss_norm + audio_mseloss_norm) / 7

        running_loss += loss.item()
  print ('epoch = %d validation loss: cfr = %.4f, cfm = %.4f, sfri = %.4f, sfra = %.4f, sim_mse = %.4f, image_mse = %.4f audio_mse = %.4f' \
         %(model_state_dict['epoch_num'], cfr_loss_epoch/len(val_dataloader), cfm_loss_epoch/len(val_dataloader), sfri_loss_epoch/len(val_dataloader), sfra_loss_epoch/len(val_dataloader), sim_mseloss_epoch/len(val_dataloader), image_mseloss_epoch/len(val_dataloader), audio_mseloss_epoch/len(val_dataloader)))
  print ('epoch = %d validation loss = %.4f' %(model_state_dict['epoch_num'], running_loss/len(val_dataloader)))
  loss_dict['cfr_loss'][3].append(cfr_loss_epoch/len(train_dataloader))
  loss_dict['cfm_loss'][3].append(cfm_loss_epoch/len(train_dataloader))
  loss_dict['sfri_loss'][3].append(sfri_loss_epoch/len(train_dataloader))
  loss_dict['sfra_loss'][3].append(sfra_loss_epoch/len(train_dataloader))
  loss_dict['sim_mseloss'][3].append(sim_mseloss_epoch/len(train_dataloader))
  loss_dict['image_mseloss'][3].append(image_mseloss_epoch/len(train_dataloader))
  loss_dict['audio_mseloss'][3].append(audio_mseloss_epoch/len(train_dataloader))
  loss_dict['val_loss'].append(running_loss/len(val_dataloader))


  scheduler.step()
  model_state_dict['learning_rate'] = opt.state_dict()['param_groups'][0]['lr']
  image_backbone.to("cpu")
  audio_backbone.to("cpu")
  single_modal_model.to("cpu")
  cross_modal_model.to("cpu")
  torch.save(image_backbone, os.path.join(model_path, f'image_{backbone_type}.pth'))
  torch.save(audio_backbone, os.path.join(model_path, f'audio_{backbone_type}.pth'))
  torch.save(single_modal_model, os.path.join(model_path, f'single_modal_{backbone_type}.pth'))
  torch.save(cross_modal_model, os.path.join(model_path, f'cross_modal_{backbone_type}.pth'))
  with open(os.path.join(model_path,'model_state_dict.pkl'), 'wb') as fp:
      pickle.dump(model_state_dict, fp)
  with open(os.path.join(model_path,'training_loss_dict.pkl'), 'wb') as fp:
      pickle.dump(loss_dict, fp)  
  if loss_dict['val_loss'][-1] < model_state_dict['min_loss']:
      model_state_dict['min_loss'] = loss_dict['val_loss'][-1]
      model_state_dict['min_loss_epochs'] = model_state_dict['epoch_num']
      counter = 0
      # saving models for lowest loss
      print ('saving model at epoch e = %d' %(model_state_dict['epoch_num']))
      torch.save(image_backbone, os.path.join(model_path, f'image_{backbone_type}_minloss.pth'))
      torch.save(audio_backbone, os.path.join(model_path, f'audio_{backbone_type}_minloss.pth'))
      torch.save(single_modal_model, os.path.join(model_path, f'single_modal_{backbone_type}_minloss.pth'))
      torch.save(cross_modal_model, os.path.join(model_path, f'cross_modal_{backbone_type}_minloss.pth'))
  elif np.isnan(loss_dict['val_loss'][-1]):
      print('NAN LOSS !')
      break


print ('completed training')

# f, (ax1, ax2) = plt.subplots(1, 2, figsize = (6, 6))
# f.suptitle('emotic')
# ax1.plot(range(0,len(train_loss)),train_loss, color='Blue')
# ax2.plot(range(0,len(val_loss)),val_loss, color='Red')
# ax1.legend(['train'])
# ax2.legend(['val'])
# plt.savefig(os.path.join(results_path, f'{type(opt).__name__}_train_valloss.png'))