import torch
import torch.nn as nn


class Image_Backbone(nn.Module):
  ''' The feature extractor of image, combined with Resnet50/ViT and a fully connected layer'''
  def __init__(self, backbone_module, last_dim, args):
    super(Image_Backbone, self).__init__()
    self.backbone_module = backbone_module
    self.backbone = args.backbone
    self.last_dim = last_dim

    if args.fine_tune:
      for param in self.backbone_module.parameters():       # Fine-tune backbone model
          param.requires_grad = True
    else:
      for param in self.backbone_module.parameters():       # Not fine-tune it
          param.requires_grad = False

    if self.backbone == 'resnet':
      self.fc = nn.Linear((self.last_dim), 512)     #[ba, 2048]

    elif self.backbone == 'transformers':           #[bz, 97, 768] 97*768=74496 
      # self.fc = nn.Linear(197*(self.last_dim), 512)   
      self.fc = nn.Linear(self.last_dim, 512)  

  def forward(self, x_image):
    if self.backbone == 'resnet':
        x = self.backbone_module(x_image)
        # print(x.shape)
        x = x.view(x.size(0), -1)
        out = self.fc(x)
    elif self.backbone == 'transformers':
        x = self.backbone_module(x_image).last_hidden_state
        # x = x.view(x.size(0), -1)
        # x = x.reshape(x.size(0), -1)
        x = x[:, 0, :]
        # print(x.shape)
        out = self.fc(x)

    return out

class Audio_Backbone(nn.Module):
  ''' The feature extractor of audio, combined with Resnet18 and a fully connected layer'''
  def __init__(self, backbone_module, last_dim, args):
    super(Audio_Backbone, self).__init__()
    self.backbone_module = backbone_module
    self.backbone = args.backbone
    self.last_dim = last_dim

    if args.fine_tune:
      for param in self.backbone_module.parameters():       # Fine-tune backbone model
          param.requires_grad = True
    else:
      for param in self.backbone_module.parameters():       # Not fine-tune it
          param.requires_grad = False

    if self.backbone == 'resnet':
      self.fc = nn.Linear((self.last_dim), 512)

    elif self.backbone == 'transformers':
      # self.fc = nn.Linear(96*(self.last_dim), 512)
      self.fc = nn.Linear(self.last_dim, 512)

  def forward(self, x_audio):
    if self.backbone == 'resnet':
        x = self.backbone_module(x_audio)
        # print(x.shape)
        x = x.view(x.size(0), -1)
        out = self.fc(x)
    elif self.backbone == 'transformers':
        x = self.backbone_module.extract_features(x_audio, padding_mask=None)[0]
        x = x[:, 0, :]
        # x = x.reshape(x.size(0), -1)
        # print(x.shape)
        out = self.fc(x)
    return out

class CMmodel(nn.Module):
  ''' Cross modal prediction Model, predict the similarity score'''
  def __init__(self, image_features, audio_features):
    super(CMmodel,self).__init__()
    self.num_image_features = image_features
    self.num_audio_features = audio_features
    self.fc1 = nn.Linear((self.num_image_features + self.num_audio_features), 256)
    self.bn1 = nn.BatchNorm1d(256)
    self.d1 = nn.Dropout(p=0.5)
    self.fc2 = nn.Linear(256, 128)
    self.bn2 = nn.BatchNorm1d(128)
    self.fc_out = nn.Linear(128, 1)
    self.relu = nn.ReLU()
    self.sigmoid = nn.Sigmoid()

  def forward(self, x_image, x_audio):
    # print(f'num_image_features: {self.num_image_features}, num_audio_features: {self.num_audio_features}')
    image_features = x_image.view(x_image.size(0), -1)
    audio_features = x_audio.view(x_audio.size(0), -1)
    # print(f'image shape: {image_features.shape}, audio shape: {audio_features.shape}')
    x_features = torch.cat((image_features, audio_features), 1)
    x_out = self.fc1(x_features)
    x_out = self.bn1(x_out)
    x_out = self.relu(x_out)
    x_out = self.d1(x_out)
    x_out = self.fc2(x_out)
    x_out = self.bn2(x_out)
    x_out = self.relu(x_out)
    x_out = self.d1(x_out)
    x_out = self.fc_out(x_out)
    sim_out = self.sigmoid(x_out)
    return sim_out

class SMmodel(nn.Module):
  ''' Single modal prediction Model, predict the valance and arousal value'''
  def __init__(self, data_features):
    super(SMmodel,self).__init__()
    self.data_features = data_features
    self.fc1 = nn.Linear((self.data_features), 256)
    self.bn1 = nn.BatchNorm1d(256)
    self.d1 = nn.Dropout(p=0.5)
    self.fc2 = nn.Linear(256, 128)
    self.bn2 = nn.BatchNorm1d(128)
    self.fc_out = nn.Linear(128, 2)
    self.relu = nn.ReLU()
    self.sigmoid = nn.Sigmoid()

  def forward(self, x):

    # va presiction
    x = x.view(-1, self.data_features)
    x_out = self.fc1(x)
    x_out = self.bn1(x_out)
    x_out = self.relu(x_out)
    x_out = self.d1(x_out)
    x_out = self.fc2(x_out)
    x_out = self.bn2(x_out)
    x_out = self.relu(x_out)
    x_out = self.d1(x_out)
    x_out = self.fc_out(x_out)
    va_out = self.sigmoid(x_out)

    return va_out
