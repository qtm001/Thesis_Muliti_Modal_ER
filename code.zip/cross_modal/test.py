import numpy as np
from dataset_loader import test_dataset_load
import os
import args_parser
from utils.util import load_models_minloss, load_models
from tqdm import tqdm
import scipy

import torch
import torch.nn as nn 
from transformers import AutoImageProcessor, ViTModel
from utils.BEATs.BEATs import BEATs, BEATsConfig
from module import Image_Backbone, Audio_Backbone, SMmodel, CMmodel
from torchvision.models import resnet18, ResNet18_Weights
from torchvision.models import resnet50, ResNet50_Weights


def test_mae(cont_preds, cont_labels):
  mae = np.zeros(1, dtype=np.float32)
  mae = np.mean(np.abs(cont_preds - cont_labels))
  print ('MAE', mae.mean())

  return mae.mean()

def test_mse(cont_preds, cont_labels):
  mse = np.zeros(1, dtype=np.float32)
  mse = np.mean(np.square(cont_preds - cont_labels))
  print ('MSE', mse.mean())

  return mse.mean()

def zero_shot():
  model_image = ViTModel.from_pretrained("google/vit-base-patch16-224-in21k")
  last_dim_image = model_image.pooler.dense.out_features
  # BEATs audio
  checkpoint = torch.load('/mnt/data2/tianming_data/trans_models/BEATs_iter3_plus_AS2M.pt')
  cfg = BEATsConfig(checkpoint['cfg'])
  model_audio = BEATs(cfg)
  model_audio.load_state_dict(checkpoint['model'])
  # last_dim_audio = list(model_audio.children())[-1].in_features

  image_backbone = Image_Backbone(model_image, last_dim_image, args)
  audio_backbone = Audio_Backbone(model_audio, 768, args)

  cross_modal_model = CMmodel(list(image_backbone.children())[-1].out_features , list(audio_backbone.children())[-1].out_features)
  single_modal_model = SMmodel(list(image_backbone.children())[-1].out_features)

  return image_backbone, audio_backbone, cross_modal_model, single_modal_model

def zero_shot_resnet():
  image_model = resnet50(weights=ResNet50_Weights.IMAGENET1K_V2)
  last_dim_image = list(image_model.children())[-1].in_features
  model_image = nn.Sequential(*(list(image_model.children())[:-1]))
  model_audio = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)
  last_dim_audio = list(image_model.children())[-1].in_features
  model_audio = nn.Sequential(*(list(model_audio.children())[:-1]))

  image_backbone = Image_Backbone(model_image, 2048, args)
  audio_backbone = Audio_Backbone(model_audio, 512, args)

  cross_modal_model = CMmodel(list(image_backbone.children())[-1].out_features , list(audio_backbone.children())[-1].out_features)
  single_modal_model = SMmodel(list(image_backbone.children())[-1].out_features)

  return image_backbone, audio_backbone, cross_modal_model, single_modal_model

if __name__ == '__main__':
    args = args_parser.parse_args()
    results_path = args.result_dir
    optimizer = args.optimizer
    backbone_type = args.backbone

    test_dataloader, num_pairs = test_dataset_load(args)
    # image_backbone, audio_backbone, single_modal_model, cross_modal_model, state_dict, opt, scheduler = load_models_minloss(args)
    # image_backbone, audio_backbone, single_modal_model, cross_modal_model, state_dict, _, opt, scheduler = load_models(args)
    image_backbone, audio_backbone, cross_modal_model, single_modal_model = zero_shot()
    device = torch.device("cuda:3" if torch.cuda.is_available() else "cpu")
    # minloss = state_dict['min_loss']
    # minloss_epoch = state_dict['min_loss_epochs']
    # print(f'Start test, test with min val loss {minloss} at {minloss_epoch} epochs')
    if not os.path.exists(results_path):
        os.makedirs(results_path)


    val_image_preds = np.zeros(num_pairs)
    aro_image_preds = np.zeros(num_pairs)
    val_image_labels = np.zeros(num_pairs)
    aro_image_labels = np.zeros(num_pairs)
    val_audio_preds = np.zeros(num_pairs)
    aro_audio_preds = np.zeros(num_pairs)
    val_audio_labels = np.zeros(num_pairs)
    aro_audio_labels = np.zeros(num_pairs)
    sim_preds = np.zeros(num_pairs)
    sim_labels = np.zeros(num_pairs)
    clips_ids = []
    image_ids = []

    with torch.no_grad():
        image_backbone.to(device)
        audio_backbone.to(device)
        cross_modal_model.to(device)
        single_modal_model.to(device)
        image_backbone.eval()
        audio_backbone.eval()
        cross_modal_model.eval()
        single_modal_model.eval()
        indx = 0
        print ('starting testing')
        for image_feature, audio_feature, similarity_score, image_va, audio_va, image_id, audio_id in tqdm(iter(test_dataloader)):
            image_feature = image_feature.to(device)
            audio_feature = audio_feature.to(device)
            similarity_score = similarity_score.to(device)
            image_va = image_va.to(device)
            audio_va = audio_va.to(device)

            pred_image_context = image_backbone(image_feature)
            audio_backbone = audio_backbone.float()
            pred_audio_context = audio_backbone(audio_feature.float())
            pred_sim = cross_modal_model(pred_image_context, pred_audio_context)
            pred_image_va = single_modal_model(pred_image_context)
            pred_audio_va = single_modal_model(pred_audio_context)

            pred_sim_np = pred_sim.to("cpu").data.numpy()
            pred_image_va_np = pred_image_va.to("cpu").data.numpy()
            pred_audio_va_np = pred_audio_va.to("cpu").data.numpy()
            # print(val_image_preds.shape)
            # print(labels_val.to("cpu").data.numpy())
            # print(indx)
            val_image_preds[ indx : (indx + pred_image_va_np.shape[0])] = pred_image_va_np[:, 0]
            aro_image_preds[ indx : (indx + pred_image_va_np.shape[0])] = pred_image_va_np[:, 1]
            val_image_labels[ indx : (indx + image_va.shape[0])] = image_va[:, 0].to("cpu").data.numpy()
            aro_image_labels[ indx : (indx + image_va.shape[0])] = image_va[:, 1].to("cpu").data.numpy()
            image_ids[ indx : (indx + pred_image_va_np.shape[0])] = image_id
            val_audio_preds[ indx : (indx + pred_audio_va_np.shape[0])] = pred_audio_va_np[:, 0]
            aro_audio_preds[ indx : (indx + pred_audio_va_np.shape[0])] = pred_audio_va_np[:, 1]
            val_audio_labels[ indx : (indx + audio_va.shape[0])] = audio_va[:, 0].to("cpu").data.numpy()
            aro_audio_labels[ indx : (indx + audio_va.shape[0])] = audio_va[:, 1].to("cpu").data.numpy()
            clips_ids[ indx : (indx + pred_image_va_np.shape[0])] = audio_id
            sim_preds[ indx : (indx + pred_sim_np.shape[0])] = pred_sim_np.reshape(-1)
            sim_labels[ indx : (indx + pred_sim_np.shape[0])] = similarity_score.to("cpu").data.numpy()
            indx = indx + pred_image_va_np.shape[0]


    # print(val_preds)
    val_image_preds = val_image_preds.transpose()
    aro_image_preds = aro_image_preds.transpose()
    val_image_labels = val_image_labels.transpose()
    aro_image_labels = aro_image_labels.transpose()
    val_audio_preds = val_audio_preds.transpose()
    aro_audio_preds = aro_audio_preds.transpose()
    val_audio_labels = val_audio_labels.transpose()
    aro_audio_labels = aro_audio_labels.transpose()
    sim_preds = sim_preds.transpose()
    sim_labels = sim_labels.transpose()

    scipy.io.savemat(os.path.join(results_path, 'valance_image_preds_resnet.mat'),mdict={'id':image_ids, 'cont_preds':val_image_preds})
    scipy.io.savemat(os.path.join(results_path, 'arousal_image_preds_resnet.mat'),mdict={'id':image_ids, 'cont_preds':aro_image_preds})
    scipy.io.savemat(os.path.join(results_path, 'valence_image_labels_resnet.mat'),mdict={'id':image_ids, 'cont_labels':val_image_labels})
    scipy.io.savemat(os.path.join(results_path, 'arousal_image_labels_resnet.mat'),mdict={'id':image_ids, 'cont_labels':aro_image_labels})
    scipy.io.savemat(os.path.join(results_path, 'valance_audio_preds_resnet.mat'),mdict={'id':clips_ids, 'cont_preds':val_audio_preds})
    scipy.io.savemat(os.path.join(results_path, 'arousal_audio_preds_resnet.mat'),mdict={'id':clips_ids, 'cont_preds':aro_audio_preds})
    scipy.io.savemat(os.path.join(results_path, 'valence_audio_labels_resnet.mat'),mdict={'id':clips_ids, 'cont_labels':val_audio_labels})
    scipy.io.savemat(os.path.join(results_path, 'arousal_audio_labels_resnet.mat'),mdict={'id':clips_ids, 'cont_labels':aro_audio_labels})
    scipy.io.savemat(os.path.join(results_path, 'similarity_score_preds_resnet.mat'),mdict={'image_ids':image_ids, 'audio_ids':clips_ids, 'cont_preds':sim_preds})
    scipy.io.savemat(os.path.join(results_path, 'similarity_score_labels_resnet.mat'),mdict={'image_ids':image_ids, 'audio_ids':clips_ids, 'cont_labels':sim_labels})

    print ('completed testing')
    print ('evaluate on image')
    print ('evaluate on valance')
    val_image_mae = test_mae(val_image_preds, val_image_labels)
    val_image_mse = test_mse(val_image_preds, val_image_labels)
    print ('evaluate on arousal')
    aro_image_mae = test_mae(aro_image_preds, aro_image_labels)
    aro_image_mse = test_mse(aro_image_preds, aro_image_labels)

    print ('evaluate on audio')
    print ('evaluate on valance')
    val_audio_mae = test_mae(val_audio_preds, val_audio_labels)
    val_audio_mse = test_mse(val_audio_preds, val_audio_labels)

    print ('evaluate on arousal')
    aro_audio_mae = test_mae(aro_audio_preds, aro_audio_labels)
    aro_audio_mse = test_mse(aro_audio_preds, aro_audio_labels)

    print ('evaluate on similarity score')
    sim_mae = test_mae(sim_preds, sim_labels)
    sim_mse = test_mse(sim_preds, sim_labels)
