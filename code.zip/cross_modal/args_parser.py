import os
import torch
import argparse

def parse_args():
    parser = argparse.ArgumentParser()
    ### define the data direction
    parser.add_argument('--data_dir', type=str, required=True, help='Path to image and labels')
    parser.add_argument('--model_dir', type=str, default='models', help='Directory name in which trained model will be stored')
    parser.add_argument('--result_dir', type=str, default='results', help='Directory name in which the test reuslts will be stored')
    ### model setting
    parser.add_argument('--batch_size', type=int, default=128, help='the batch size of dataloader')
    parser.add_argument('--optimizer', type=str, default='sgd', help='the optimizer of the training function')
    parser.add_argument('--epoch_num', type=int, default=100, help='the number of epochs')
    parser.add_argument('--backbone', type=str, default='resnet', help='the encoder type', choices=['resnet', 'transformers'])
    parser.add_argument('--encoder_layers', type=int, default=1, help='the number of fc laysers after encoder', choices=[1, 3])
    ### training argument
    parser.add_argument('--fine_tune', action='store_true', help='Fine-tune the backbone or not')
    parser.add_argument('--resume', action='store_true', help='resume training')
    parser.add_argument('--debug_mode', action='store_true', help='Debug mode. Will only save a small subset of the data')

    args = parser.parse_args()
    return args