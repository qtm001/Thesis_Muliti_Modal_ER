import scipy, matplotlib.pyplot as plt, sklearn, librosa
import numpy as np
from torchvision import transforms
import torch
import torchaudio
import os
import cv2
import pandas as pd
from tqdm import tqdm
import args_parser
from utils.util import load_models_minloss, load_models, extract_data_labels, extract_data

### only music/images ###
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
def get_features(data_path, backbone_type):
    if backbone_type == 'resnet':
        x, fs = librosa.load(data_path)
        mfccs = librosa.feature.mfcc(y=x, sr=fs, n_mfcc=40)                         #MFCCs extraction
        S = np.abs(librosa.stft(x))
        chroma = librosa.feature.chroma_stft(S=S, sr=fs)                            #Chroma extraction
        contrast = librosa.feature.spectral_contrast(S=S, sr=fs)                    #Spectral contrast extraction
        y = librosa.effects.harmonic(x)
        tonnetz = librosa.feature.tonnetz(y=y, sr=fs)                               #Tonal centroid extraction
        mel_S = librosa.feature.melspectrogram(y=x, sr=fs, n_mels=128)              #Melspectrogram extraction
        music_total = np.concatenate((mfccs, chroma, contrast, tonnetz, mel_S))     #Concatenate
        music_shape = music_total.shape
        music_feature = np.zeros((music_shape[0], music_shape[1], 3))
        for i in range(len(music_feature[0][0])):
            music_feature[:, :, i] = music_total
    elif backbone_type == 'transformers':
        music_feature, sample_rate = torchaudio.load(data_path)
    return music_feature

def single_song_test(feature, model_context, model_predictor, backbone_type):

    model_context.to(device)
    model_predictor.to(device)
    
    if backbone_type == 'resnet':
        transform = transforms.Compose([transforms.ToTensor()])
        feature = transform(feature)
    feature = feature.unsqueeze(0)
    feature = feature.to(device)

  #COMPLETE VERSION
    with torch.no_grad():
        if backbone_type == 'resnet':
            model_context = model_context.float()
            pred_context = model_context(feature.float())
        elif backbone_type == 'transformers':
            pred_context = model_context(feature)
        # print(f"complete :{pred_context.shape}")
        pred_cont = model_predictor(pred_context)

        pred_cont_np = pred_cont.to("cpu").data.numpy()
        pred_cont_np = pred_cont_np.mean(axis = 0)

  #CUT VERSION
    len = int(feature.shape[-1]/87)
    cut_list = [87]*len
    cut_list.append(feature.shape[-1]%87)
    music_cut = feature.split(cut_list, dim=-1)
    music_final = torch.cat(music_cut[:-1], dim = 0)
    music_final = music_final.to(device)
    with torch.no_grad():
        if backbone_type == 'resnet':
            model_context = model_context.float()
            pred_context = model_context(feature.float())
        elif backbone_type == 'transformers':
            pred_context = model_context(feature)
        # print(f"cut :{pred_context.shape}")
        pred_cont = model_predictor(pred_context)

    pred_cont_np_cut = pred_cont.to("cpu").data.numpy()
    pred_cont_np_cut = pred_cont_np_cut.mean(axis = 0)
    # print(pred_cont_np[0][0])
    # print(pred_cont_np[1], pred_cont_np[0])

    return pred_cont_np, pred_cont_np_cut

def get_image_features(path, image_transform=None):
    image_feature = cv2.cvtColor(cv2.imread(path), cv2.COLOR_BGR2RGB)
    image_feature = cv2.resize(image_feature, (224,224))
    if image_transform is not None:
            image_feature = image_transform(image_feature)

    return image_feature

def single_image_test(feature, model_context, model_predictor, image_transform=None):

    model_context.to(device)
    model_predictor.to(device)

    feature = feature.to(device)
    with torch.no_grad():
        pred_context = model_context(feature)
        # print(f"complete :{pred_context.shape}")
        pred_cont = model_predictor(pred_context)

    pred_cont_np = pred_cont.to("cpu").data.numpy()


    return pred_cont_np

def compute_simscore(music_feature, image_feature, music_encoder, image_encoder, sim_predictor, backbone_type):
    if backbone_type == 'resnet':
        transform = transforms.Compose([transforms.ToTensor()])
        music_feature = transform(music_feature)
    
    music_encoder.to(device)
    image_encoder.to(device)
    sim_predictor.to(device)
    music_feature = music_feature.unsqueeze(0)
    music_feature = music_feature.to(device)
    image_feature = image_feature.to(device)
    with torch.no_grad():
        image_context = image_encoder(image_feature)
        if backbone_type == 'resnet':
            music_encoder = music_encoder.float()
            music_context = music_encoder(music_feature.float())
        elif backbone_type == 'transformers':
            music_context = music_encoder(music_feature)
        # print(f"complete :{pred_context.shape}")
        pred_sim = sim_predictor(image_context, music_context)
        pred_sim = pred_sim.to("cpu").data.numpy()
    return pred_sim



if __name__ == '__main__':
    args = args_parser.parse_args()
    results_path = args.result_dir
    backbone_type = args.backbone
    data_dir = args.data_dir
    image_backbone, audio_backbone, single_modal_model, cross_modal_model, state_dict, _, opt, scheduler = load_models_minloss(args)
    _, test_image, test_iva, _ = extract_data_labels(data_dir, 'test')
    test_image_dict, _, test_image_context, _ = extract_data(data_dir, 'test', backbone_type)
    img_dict = {}
    for i, img in enumerate(test_image):
        if img not in img_dict:
            img_dict[img] = test_iva[i]
    image_list = []

    for i in img_dict:
        image_list.append(i)
        if len(image_list) > 1000:
            break
        
    music_id = []
    music_res = []
    music_path = '/mnt/data2/tianming_data/data/test_song'
    version = 'short'
    music_list = os.listdir(music_path)
    music_list = list(filter(lambda x: x.find('.wav') >= 0, music_list))
    print(music_list)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    image_mean = [0.4690646, 0.4407227, 0.40508908]
    image_va_std = [0.2514227, 0.24312855, 0.24266963]
    image_norm = [image_mean, image_va_std]
    test_image_transform = transforms.Compose([transforms.ToPILImage(),
                                        transforms.ToTensor()])

    # compute similarity, audio as anchor
    music_id = []

    sim_dict = {}
    for music in music_list:
        print(f'music: {music}')
        sim_score = []
        sim_dict[music] = [[], []]
        music_feature = get_features(os.path.join(music_path, music), backbone_type)
        for image in tqdm(image_list):
            img_id = image + '.jpg'
            image_feature = test_image_context[img_id]
            sim = compute_simscore(music_feature, image_feature, audio_backbone, image_backbone, cross_modal_model, backbone_type)
            sim_score.append((img_id, sim.item()))
        sim_score = sorted(sim_score, key=lambda x: x[1], reverse=True)
        sim_dict[music][0].append(sim_score[:10])
        sim_dict[music][1].append(sim_score[-10:])

    sim_result_df = pd.DataFrame(sim_dict, index=None)
    sim_result_df.to_csv(os.path.join(results_path, 'sim_transv1.csv'), index = None,encoding = 'utf8')


