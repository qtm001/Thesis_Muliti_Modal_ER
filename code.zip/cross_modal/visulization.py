import numpy as np
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import args_parser
from dataset_loader import test_dataset_load
import os
from utils.util import load_models_minloss, load_models
from module import Image_Backbone, Audio_Backbone, SMmodel, CMmodel
import umap


import torch
import torch.nn as nn 
from transformers import AutoImageProcessor, ViTModel
from utils.BEATs.BEATs import BEATs, BEATsConfig

args = args_parser.parse_args()
test_dataloader, num_pairs = test_dataset_load(args)
image_backbone, audio_backbone, single_modal_model, cross_modal_model, state_dict, _, opt, scheduler = load_models(args)
# model_image = ViTModel.from_pretrained("google/vit-base-patch16-224-in21k")
# last_dim_image = model_image.pooler.dense.out_features
# # BEATs audio
# checkpoint = torch.load('/mnt/data2/tianming_data/trans_models/BEATs_iter3_plus_AS2M_finetuned_on_AS2M_cpt2.pt')
# cfg = BEATsConfig(checkpoint['cfg'])
# model_audio = BEATs(cfg)
# model_audio.load_state_dict(checkpoint['model'])
# last_dim_audio = list(model_audio.children())[-1].in_features

# image_backbone = Image_Backbone(model_image, last_dim_image, args)
# audio_backbone = Audio_Backbone(model_audio, last_dim_audio, args)


cross_modal_model = CMmodel(list(image_backbone.children())[-1].out_features , list(audio_backbone.children())[-1].out_features)
single_modal_model = SMmodel(list(image_backbone.children())[-1].out_features)

# tsne = TSNE(n_components=2, random_state=42)
pca = PCA(n_components=2)

device = torch.device("cuda:3" if torch.cuda.is_available() else "cpu")
with torch.no_grad():
    image_backbone.to(device)
    audio_backbone.to(device)
    cross_modal_model.to(device)
    single_modal_model.to(device)
    image_backbone.eval()
    audio_backbone.eval()
    cross_modal_model.eval()
    single_modal_model.eval()
    for image_feature, audio_feature, similarity_score, image_va, audio_va, image_id, audio_id in iter(test_dataloader):
            image_feature = image_feature.to(device)
            audio_feature = audio_feature.to(device)
            pred_image_context = image_backbone(image_feature).cpu().numpy()
            audio_backbone = audio_backbone.float()
            pred_audio_context = audio_backbone(audio_feature.float()).cpu().numpy()
            # combined_embedding = torch.cat([pred_image_context, pred_audio_context], dim=0).cpu().numpy()
            break
high_music = []
low_music = []
for i, sim in enumerate(similarity_score):
    if sim > 0.5:
        high_music.append(pred_audio_context[i])
    else:
        low_music.append(pred_audio_context[i])
combined_embedding = np.concatenate([pred_image_context, high_music, low_music], axis=0)
# embedded_image = tsne.fit_transform(pred_image_context)
# embedded_audio = tsne.fit_transform(pred_audio_context)
# umap_embedded = umap.UMAP(n_components=2).fit_transform(combined_embedding)
pca_result = pca.fit_transform(combined_embedding)
# 绘制可视化结果
# plt.scatter(embedded_image[:, 0], embedded_image[:, 1], label='Images embedding', s=10, alpha=0.5)
# plt.scatter(embedded_audio[:, 0], embedded_audio[:, 1], label='Music embedding', s=10, color='r', alpha=0.5)

# plt.scatter(umap_embedded[:128, 0], umap_embedded[:128, 1], label='Images embedding')
# plt.scatter(umap_embedded[128:, 0], umap_embedded[128:, 1], label='Music embedding')
print(len(low_music))

plt.scatter(pca_result[(128+len(high_music)):, 0], pca_result[(128+len(high_music)):, 1], label='low Music embedding', s=10, alpha=0.5, color='b')
plt.scatter(pca_result[128:len(high_music), 0], pca_result[128:len(high_music), 1], label='high Music embedding', s=10, color='g')
plt.scatter(pca_result[:128, 0], pca_result[:128, 1], label='Images embedding', s=10, color='r', alpha=0.5)
plt.legend()
plt.savefig('/home/tianming/final_structure/figure/visul/test_pca_v2nft.png')
plt.show()