import random
import math
from utils.util import extract_data_labels, extract_data

import torch
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader


class CDCMLDataset(Dataset):
    def __init__(self, image_dict, audio_dict, image_list, audio_list, image_context, audio_context, image_va_list, audio_va_list, backbone_type, image_transform=None, image_norm=None, audio_transform=None):
        self.image_dict = image_dict
        self.audio_dict = audio_dict
        self.image_list = image_list
        self.audio_list = audio_list
        self.image_context = image_context
        self.audio_context = audio_context
        self.sigma = 0.39707127407070947
        self.image_va_list = image_va_list
        self.audio_va_list = audio_va_list
        self.backbone = backbone_type
        self.image_transform = image_transform
        self.image_norm = transforms.Normalize(image_norm[0], image_norm[1])
        self.audio_transform = audio_transform
    def __len__(self):
        return len(self.image_list)

    def __getitem__(self, index):
        # Load and preprocess image data

        # Get valance & arousal scores for the current data
        image_va = self.image_va_list[index]
        audio_va = self.audio_va_list[index]

        # Compute the similarity score for image-audio pair
        similarity_score = self.compute_sim_score(self.euclidean_distance(image_va, audio_va))
        # Get a random audio index for cfr loss
        image_index_cfr, image_audio_sim, audio_index_cfr, audio_image_sim = self.cfrloos_data_index(index, self.audio_list[index], self.image_list[index])

        # Get neighbor of selected data for sfr loss
        index_n1, index_n2 = self.get_neibors_index(index)
        image_va1 = self.image_va_list[index_n1]
        image_va2 = self.image_va_list[index_n1]
        audio_va1 = self.audio_va_list[index_n1]
        audio_va2 = self.audio_va_list[index_n2]

        ### get data features
        if self.backbone == 'resnet':
            image_feature = self.image_norm(self.image_transform(self.image_context[self.image_dict[self.image_list[index]+'.jpg']]))
            audio_feature = self.audio_transform(self.audio_context[self.audio_dict[self.audio_list[index]+'.wav']])
            image_feature_cfr = self.image_norm(self.image_transform(self.image_context[self.image_dict[self.image_list[image_index_cfr]+'.jpg']]))
            audio_feature_cfr = self.audio_transform(self.audio_context[self.audio_dict[self.audio_list[audio_index_cfr]+'.wav']])
            image_n1 = self.image_norm(self.image_transform(self.image_context[self.image_dict[self.image_list[index_n1]+'.jpg']]))
            image_n2 = self.image_norm(self.image_transform(self.image_context[self.image_dict[self.image_list[index_n2]+'.jpg']]))
            audio_n1 = self.audio_transform(self.audio_context[self.audio_dict[self.audio_list[index_n1]+'.wav']])
            audio_n2 = self.audio_transform(self.audio_context[self.audio_dict[self.audio_list[index_n2]+'.wav']])
        elif self.backbone == 'transformers':
            image_feature = self.image_context[self.image_list[index]+'.jpg'].squeeze()
            audio_feature = self.audio_context[self.audio_list[index]]
            image_feature_cfr = self.image_context[self.image_list[image_index_cfr]+'.jpg'].squeeze()
            audio_feature_cfr = self.audio_context[self.audio_list[audio_index_cfr]]
            image_n1 = self.image_context[self.image_list[index_n1]+'.jpg'].squeeze()
            image_n2 = self.image_context[self.image_list[index_n2]+'.jpg'].squeeze()
            audio_n1 = self.audio_context[self.audio_list[index_n1]]
            audio_n2 = self.audio_context[self.audio_list[index_n2]]
        # return self.image_norm(self.image_transform(image_feature)), self.audio_norm(self.audio_transform(audio_feature)), torch.tensor(similarity_score, dtype=torch.float32), torch.tensor(image_va, dtype=torch.float32), torch.tensor(audio_va, dtype=torch.float32), \
        #       self.image_norm(self.image_transform(image_feature_cfr)), torch.tensor(image_audio_sim, dtype=torch.float32), self.audio_norm(self.audio_transform(audio_feature_cfr)), torch.tensor(audio_image_sim, dtype=torch.float32), \
        #         self.image_norm(self.image_transform(image_n1)), self.image_norm(self.image_transform(image_n2)), torch.tensor(image_va1, dtype=torch.float32), torch.tensor(image_va2, dtype=torch.float32), \
        #             self.audio_norm(self.audio_transform(audio_n1)), self.audio_norm(self.audio_transform(audio_n2)), torch.tensor(audio_va1, dtype=torch.float32), torch.tensor(audio_va2, dtype=torch.float32)
        return image_feature, audio_feature, torch.tensor(similarity_score, dtype=torch.float32), torch.tensor(image_va, dtype=torch.float32), torch.tensor(audio_va, dtype=torch.float32), \
              image_feature_cfr, torch.tensor(image_audio_sim, dtype=torch.float32), audio_feature_cfr, torch.tensor(audio_image_sim, dtype=torch.float32), \
                image_n1, image_n2, torch.tensor(image_va1, dtype=torch.float32), torch.tensor(image_va2, dtype=torch.float32), \
                    audio_n1, audio_n2, torch.tensor(audio_va1, dtype=torch.float32), torch.tensor(audio_va2, dtype=torch.float32)


    def cfrloos_data_index(self, index, audio_id, image_id):
        image_index = index
        audio_index = index
        while self.image_list[image_index] == image_id:
          image_index = random.randint(0, self.__len__() - 1)
        while self.audio_list[audio_index] == audio_id:
          audio_index = random.randint(0, self.__len__() - 1)
        image_audio_sim = self.compute_sim_score(self.euclidean_distance(self.image_va_list[index], self.audio_va_list[audio_index]))
        audio_image_sim = self.compute_sim_score(self.euclidean_distance(self.image_va_list[image_index], self.audio_va_list[index]))
        return image_index, image_audio_sim, audio_index, audio_image_sim

    def get_neibors_index(self, index):
        length = self.__len__()
        if index == 0:
            return length-1, index+1
        elif index == length-1:
            return index-1, 0
        else:
            return index-1, index+1
    def euclidean_distance(self, image_va, audio_va):
        if len(image_va) != len(audio_va):
          raise ValueError("diff dim")

        squared_distance = sum((x - y) ** 2 for x, y in zip(image_va, audio_va))
        distance = math.sqrt(squared_distance)

        return distance
    def compute_sim_score(self, euclidean_distance):

        return math.exp(-(euclidean_distance/self.sigma))

    def audio_norm(self, audio_context):
        # print(audio_context.shape)
        height, width, channels = audio_context.shape

        audio_mean = torch.mean(audio_context, dim=(0, 1, 2), keepdim=True)
        audio_std = torch.std(audio_context, dim=(0, 1, 2), keepdim=True)

        audio_context_norm = (audio_context - audio_mean) / (audio_std + 1e-8)

        return audio_context_norm


class CDCMLTest(Dataset):
    def __init__(self, image_dict, audio_dict, image_list, audio_list, image_context, audio_context, image_va_list, audio_va_list, backbone_type, image_transform=None, image_norm=None, audio_transform=None):
        self.image_dict = image_dict
        self.audio_dict = audio_dict
        self.image_list = image_list
        self.audio_list = audio_list
        self.image_context = image_context
        self.audio_context = audio_context
        self.sigma = 0.39707127407070947
        self.image_va_list = image_va_list
        self.audio_va_list = audio_va_list
        self.backbone = backbone_type
        self.image_transform = image_transform
        self.image_norm = transforms.Normalize(image_norm[0], image_norm[1])
        self.audio_transform = audio_transform
    def __len__(self):
        return len(self.image_list)

    def __getitem__(self, index):
        # Load and get the data id
        image_id = self.image_list[index]+'.jpg'
        audio_id = self.audio_list[index]+'.wav'

        # Get valance & arousal scores for the current data
        image_va = self.image_va_list[index]
        audio_va = self.audio_va_list[index]

        # Compute the similarity score for image-audio pair
        similarity_score = self.compute_sim_score(self.euclidean_distance(image_va, audio_va))

        # get data
        if self.backbone == 'resnet':
            image_feature = self.image_norm(self.image_transform(self.image_context[self.image_dict[self.image_list[index]+'.jpg']]))
            audio_feature = self.audio_transform(self.audio_context[self.audio_dict[self.audio_list[index]+'.wav']])
        elif self.backbone == 'transformers':
            image_feature = self.image_context[self.image_list[index]+'.jpg'].squeeze()
            audio_feature = self.audio_context[self.audio_list[index]]
        
        return image_feature, audio_feature, torch.tensor(similarity_score)\
                , torch.tensor(image_va), torch.tensor(audio_va), image_id, audio_id

    def euclidean_distance(self, image_va, audio_va):
        if len(image_va) != len(audio_va):
          raise ValueError("diff dim")

        squared_distance = sum((x - y) ** 2 for x, y in zip(image_va, audio_va))
        distance = math.sqrt(squared_distance)

        return distance
    def compute_sim_score(self, euclidean_distance):

        return math.exp(-(euclidean_distance/self.sigma))
    
    def audio_norm(self, audio_context):
        # print(audio_context.shape)
        height, width, channels = audio_context.shape

        audio_mean = torch.mean(audio_context, dim=(0, 1, 2), keepdim=True)
        audio_std = torch.std(audio_context, dim=(0, 1, 2), keepdim=True)

        audio_context_norm = (audio_context - audio_mean) / (audio_std + 1e-8)

        return audio_context_norm
    
def train_dataset_load(args):
    data_dir = args.data_dir
    backbone_type = args.backbone
    train_audio, train_image, train_iva, train_ava = extract_data_labels(data_dir, 'train')
    val_audio, val_image, val_iva, val_ava = extract_data_labels(data_dir, 'val')

    train_image_dict, train_audio_dict, train_image_context, train_audio_context = extract_data(data_dir, 'train', backbone_type)
    val_image_dict, val_audio_dict, val_image_context, val_audio_context = extract_data(data_dir, 'val', backbone_type)
    
    ### load the dataloader
    batch_size = args.batch_size

    image_mean = [0.4690646, 0.4407227, 0.40508908]
    image_va_std = [0.2514227, 0.24312855, 0.24266963]
    image_norm = [image_mean, image_va_std]

    train_image_transform = transforms.Compose([transforms.ToPILImage(),
                                        transforms.RandomHorizontalFlip(),
                                        transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4),
                                        transforms.ToTensor()])

    audio_transform = transforms.Compose([
                                        transforms.ToTensor()])

    train_dataset = CDCMLDataset(image_dict=train_image_dict, audio_dict=train_audio_dict, image_list=train_image, audio_list=train_audio,\
                                    image_context=train_image_context, audio_context=train_audio_context,\
                                    image_va_list=train_ava, audio_va_list=train_iva, backbone_type=backbone_type, image_transform=train_image_transform,\
                                        image_norm=image_norm, audio_transform=audio_transform)
    val_dataset = CDCMLDataset(image_dict=val_image_dict, audio_dict=val_audio_dict, image_list=val_image, audio_list=val_audio,\
                                    image_context=val_image_context, audio_context=val_audio_context,\
                                    image_va_list=val_iva, audio_va_list=val_ava, backbone_type=backbone_type, image_transform=train_image_transform,\
                                        image_norm=image_norm, audio_transform=audio_transform)

    train_loader = DataLoader(train_dataset, batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size, shuffle=False)

    return train_loader, val_loader

def test_dataset_load(args):
    data_dir = args.data_dir
    backbone_type = args.backbone
    test_audio, test_image, test_iva, test_ava = extract_data_labels(data_dir, 'test')
    test_image_dict, test_audio_dict, test_image_context, test_audio_context = extract_data(data_dir, 'test', backbone_type)
    image_mean = [0.4690646, 0.4407227, 0.40508908]
    image_va_std = [0.2514227, 0.24312855, 0.24266963]
    image_norm = [image_mean, image_va_std]
    test_image_transform = transforms.Compose([transforms.ToPILImage(),
                                        transforms.ToTensor()])
    audio_transform = transforms.Compose([
                                        transforms.ToTensor()])
    test_dataset = CDCMLTest(image_dict=test_image_dict, audio_dict=test_audio_dict, image_list=test_image, audio_list=test_audio,\
                                    image_context=test_image_context, audio_context=test_audio_context,\
                                    image_va_list=test_iva, audio_va_list=test_ava, backbone_type=backbone_type, image_transform=test_image_transform, image_norm=image_norm, \
                                        audio_transform=audio_transform)
    
    batch_size = args.batch_size
    test_loader = DataLoader(test_dataset, batch_size, shuffle=False)
    num_pirs = test_dataset.__len__()
    return test_loader, num_pirs
    
