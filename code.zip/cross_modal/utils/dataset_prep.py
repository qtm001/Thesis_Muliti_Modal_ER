import argparse 
import pandas as pd 
import csv 
import cv2
import numpy as np 
import os 
from scipy.io import loadmat 
from tqdm import tqdm 
import numpy, scipy, matplotlib.pyplot as plt, sklearn, librosa


def get_features(data_path):
    x, fs = librosa.load(data_path)
    mfccs = librosa.feature.mfcc(y=x, sr=fs, n_mfcc=40)                         #MFCCs extraction
    S = np.abs(librosa.stft(x))
    chroma = librosa.feature.chroma_stft(S=S, sr=fs)                            #Chroma extraction
    contrast = librosa.feature.spectral_contrast(S=S, sr=fs)                    #Spectral contrast extraction
    y = librosa.effects.harmonic(x)
    tonnetz = librosa.feature.tonnetz(y=y, sr=fs)                               #Tonal centroid extraction
    mel_S = librosa.feature.melspectrogram(y=x, sr=fs, n_mels=128)              #Melspectrogram extraction
    music_total = np.concatenate((mfccs, chroma, contrast, tonnetz, mel_S))     #Concatenate
    music_shape = music_total.shape
    music_tile = np.zeros((music_shape[0], music_shape[1], 3))
    for i in range(len(music_tile[0][0])):
        music_tile[:, :, i] = music_total
    return music_tile

class audio_label:
    def __init__(self, filename, folder, valence, arousal):
        self.filename = filename + '.wav'
        self.folder = folder
        self.cont = []
        self.cont_annotators = 0
        self.set_cont(valence, arousal)
        self.check_cont()

    def set_cont(self, valence, arousal):
        self.cont = [valence, arousal]
        # print(f'The count is {self.cont}')
        self.cont_annotators = 1

    def check_cont(self):
        for c in self.cont:
            # print(f'the count is {c}')
            if np.isnan(c):
                self.cont_annotators = 0
                break
            
class image_label:
    def __init__(self, filename, folder, valence, arousal):
        self.filename = filename + '.jpg'
        self.folder = folder
        self.cont = []
        self.cont_annotators = 0
        self.set_cont(valence, arousal)
        self.check_cont()

    def set_cont(self, valence, arousal):
        self.cont = [valence, arousal]
        # print(f'The count is {self.cont}')
        self.cont_annotators = 1

    def check_cont(self):
        for c in self.cont:
            # print(f'the count is {c}')
            if np.isnan(c):
                self.cont_annotators = 0
                break

def prepare_data(df, data_path_src, save_dir, dataset_type='train', data_type='image', generate_npy=False, debug_mode=False):
  '''
  Prepare csv files and save preprocessed data in npy files. 
  :param df: dataframe object for data. 
  :param data_path_src: Path of the parent directory containing the emotic images folders (mscoco, framesdb, emodb_small, ade20k)
  :param save_dir: Path of the directory to save the csv files and the npy files (if generate_npy files is True)
  :param dataset_type: Type of the dataset (train, val or test). Variable used in the name of csv files and npy files. 
  :param generate_npy: If True the data is preprocessed and saved in npy files. Npy files are later used for training. 
  '''
  data_set = list()

  if generate_npy:
    context_arr = list()
    cont_arr = list()
  
  to_break = 0
  path_not_exist = 0
  cont_zero = 0
  idx = 0
  folder = data_type
  for ex_idx, ex in tqdm(enumerate(df.iterrows())):
    # print(f'\n The ex is {ex[1][1]}')
    if data_type == 'image':
      it = image_label(ex[1][0], folder, ex[1][1], ex[1][2])
    elif data_type == 'audio':
      it = audio_label(ex[1][0], folder, ex[1][1], ex[1][2]) 
    try:
        data_path = os.path.join(data_path_src,it.folder,it.filename)
        if not os.path.exists(data_path):
            path_not_exist += 1
            print ('path not existing', ex_idx, data_path)
            continue
        else:
            if data_type == 'image':
              context = cv2.cvtColor(cv2.imread(data_path),cv2.COLOR_BGR2RGB)
              context_cv = cv2.resize(context, (224,224))
            elif data_type == 'audio':
              context_cv = get_features(data_path)
    except Exception as e:
        to_break += 1
        if debug_mode == True:
            print ('breaking at idx=%d, %d due to exception=%r' %(ex_idx, idx, e))
        continue
    if (it.cont_annotators == 0):
        cont_zero += 1
        continue
    data_set.append(it)  
    if generate_npy == True:
        context_arr.append(context_cv)
        cont_arr.append(np.array(it.cont))
    if idx % 1000 == 0 and debug_mode==False:
        print (" Preprocessing data. Index = ", idx)
    elif idx % 20 == 0 and debug_mode==True:
        print (" Preprocessing data. Index = ", idx)
    idx = idx + 1
    # for debugging purposes
    if debug_mode == True and idx >= 104:
      print (' ######## Breaking data prep step', idx, ex_idx, ' ######')
      print (to_break, path_not_exist)
      cv2.imwrite(os.path.join(save_dir, 'context1.png'), context_arr[-1])
      # cv2.imwrite(os.path.join(save_dir, 'body1.png'), body_arr[-1])
      break
  print (to_break, path_not_exist)
  
  csv_path = os.path.join(save_dir, "%s_new.csv" %(dataset_type))
  with open(csv_path, 'w') as csvfile:
    filewriter = csv.writer(csvfile, delimiter=',', dialect='excel')
    # row = ['Index', 'Folder', 'Filename', 'Image Size', 'BBox', 'Categorical_Labels', 'Continuous_Labels', 'Gender', 'Age']
    row = ['Index', 'Folder', 'Filename', 'Continuous_Labels']
    filewriter.writerow(row)
    for idx, ex in enumerate(data_set):
        row = [idx, ex.folder, ex.filename, ex.cont]
        filewriter.writerow(row)
  print ('wrote file ', csv_path)

  if generate_npy == True: 
    context_arr = np.array(context_arr)
    cont_arr = np.array(cont_arr)
    print (f"The length of data {len(data_set)}, the shape of context data {context_arr.shape}")
    np.save(os.path.join(save_dir,'%s_context_arr.npy' %(dataset_type)), context_arr)
    np.save(os.path.join(save_dir,'%s_cont_arr.npy' %(dataset_type)), cont_arr)
    print (context_arr.shape, cont_arr.shape)
  print ('completed generating %s data files' %(dataset_type))

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', type=str, required=True, help='Path to image and labels')
    parser.add_argument('--save_dir_name', type=str, default='emotic_pre', help='Directory name in which preprocessed data will be stored')
    parser.add_argument('--label', type=str,  default='all', choices=['train', 'val', 'test', 'all'])
    parser.add_argument('--data_type', type=str,  default='image', choices=['image', 'audio'])
    parser.add_argument('--generate_npy', action='store_true', help='Generate npy files')
    parser.add_argument('--debug_mode', action='store_true', help='Debug mode. Will only save a small subset of the data')
    # Generate args
    args = parser.parse_args()
    return args

if __name__ == '__main__':
    args = parse_args()
    data_path_src = args.data_dir
    save_path = os.path.join(args.data_dir, args.save_dir_name)
    data_type = args.data_type
    if not os.path.exists(save_path):
      os.makedirs(save_path)
    
    if args.label.lower() == 'all':
      labels = ['train', 'val', 'test']
    else:
      labels = [args.label.lower()]
    for label in labels:
      print ('loading dataframe')
      df = pd.read_csv(os.path.join(data_path_src, f'{args.save_dir_name}/{args.label.lower()}.csv'))
      print (f'starting label: {label}, data type: {data_type}')
      prepare_data(df, data_path_src, save_path, dataset_type=label, data_type=data_type, generate_npy=args.generate_npy, debug_mode=args.debug_mode)



