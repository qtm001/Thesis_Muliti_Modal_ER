import os
import pickle
import numpy as np

from torch.autograd import Function
import torch
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR

def extract_data_labels(data_path, data_type):
    audio_names = []
    image_names = []
    image_va_list = []
    audio_va_list = []

    with open(os.path.join(data_path, f'{data_type}_scale.txt'), 'r') as f:
      for line in f:
          audio_name, image_name, _, audio_va, image_va = line.strip().split()
          audio_names.append(audio_name)
          image_names.append(image_name)
          audio_va_list.append(list(map(float, audio_va.split(','))))
          image_va_list.append(list(map(float, image_va.replace('\n', '').split(','))))

    return audio_names, image_names, image_va_list, audio_va_list

def extract_data(data_path, data_type, backbone_type):
    if backbone_type == 'resnet':
        image_context = np.load(os.path.join(data_path, f'{data_type}_image_context.npy'))
        audio_context = np.load(os.path.join(data_path, f'{data_type}_audio_context.npy'))
    elif backbone_type == 'transformers':
        image_context = torch.load(os.path.join(data_path, f'transformer_data/{data_type}_image_dict.pt'))
        audio_context = torch.load(os.path.join(data_path, f'transformer_data/{data_type}_audio_dict.pt'))
    with open(os.path.join(data_path, f'{data_type}_image_dict.pkl'), 'rb') as fp:
        image_dict = pickle.load(fp)
    with open(os.path.join(data_path, f'{data_type}_audio_dict.pkl'), 'rb') as fp:
        audio_dict = pickle.load(fp)

    return image_dict, audio_dict, image_context, audio_context

class Squared_L2dist(Function):
    def __init__(self, p):
        super(Squared_L2dist, self).__init__()
        self.norm = p

    def forward(self, x1, x2, d):
        eps = 1e-4 / x1.size(0)
        diff = torch.abs(x1 - x2)
        out = torch.pow(diff, self.norm).sum(dim=d)
        return out + eps
    
def load_models(args):
    backbone_type = args.backbone
    model_dir = args.model_dir
    # with open(os.path.join(model_dir, 'model_state_dict.pkl'), 'rb') as fp:
    #     state_dict = pickle.load(fp)
    # with open(os.path.join(model_dir, 'training_loss_dict.pkl'), 'rb') as fp:
    #     loss_dict = pickle.load(fp)
    # with open(os.path.join(model_dir, 'model_state_dict_v1.pkl'), 'rb') as fp:
    #     state_dict = pickle.load(fp)
    # with open(os.path.join(model_dir, 'training_loss_dict_v1.pkl'), 'rb') as fp:
    #     loss_dict = pickle.load(fp)
    with open(os.path.join(model_dir, 'model_state_dict.pkl'), 'rb') as fp:
        state_dict = pickle.load(fp)
    with open(os.path.join(model_dir, 'training_loss_dict.pkl'), 'rb') as fp:
        loss_dict = pickle.load(fp)
    # image_model = torch.load(os.path.join(model_dir, f'image_{backbone_type}_v2.pth'))
    # audio_model = torch.load(os.path.join(model_dir, f'audio_{backbone_type}_v2.pth'))
    # single_modal = torch.load(os.path.join(model_dir, f'single_modal_{backbone_type}_v2.pth'))
    # cross_modal = torch.load(os.path.join(model_dir, f'cross_modal_{backbone_type}_v2.pth'))
    image_model = torch.load(os.path.join(model_dir, f'image_{backbone_type}_v1.pth'))
    audio_model = torch.load(os.path.join(model_dir, f'audio_{backbone_type}_v1.pth'))
    single_modal = torch.load(os.path.join(model_dir, f'single_modal_{backbone_type}_v1.pth'))
    cross_modal = torch.load(os.path.join(model_dir, f'cross_modal_{backbone_type}_v1.pth'))
    # image_model = torch.load(os.path.join(model_dir, f'image_{backbone_type}.pth'))
    # audio_model = torch.load(os.path.join(model_dir, f'audio_{backbone_type}.pth'))
    # single_modal = torch.load(os.path.join(model_dir, f'single_modal_{backbone_type}.pth'))
    # cross_modal = torch.load(os.path.join(model_dir, f'cross_modal_{backbone_type}.pth'))
    optimizer = state_dict['optimizer']
    if optimizer == 'SGD':
        opt = optim.SGD((list(cross_modal.parameters()) + list(single_modal.parameters()) \
                  + list(image_model.parameters()) + list(audio_model.parameters())), lr=state_dict['learning_rate'], weight_decay=5e-4, momentum=0.9)
    elif optimizer == 'Adam':
        opt = optim.Adam((list(cross_modal.parameters()) + list(single_modal.parameters()) \
                  + list(image_model.parameters()) + list(audio_model.parameters())), lr=state_dict['learning_rate'], weight_decay=5e-4)
    scheduler = StepLR(opt, step_size=10, gamma=0.1)
    return image_model, audio_model, single_modal, cross_modal, state_dict, loss_dict, opt, scheduler

def load_models_minloss(args):
    backbone_type = args.backbone
    model_dir = args.model_dir
    # with open(os.path.join(model_dir, 'model_state_dict_v2.pkl'), 'rb') as fp:
    #     state_dict = pickle.load(fp)
    # with open(os.path.join(model_dir, 'training_loss_dict_v2.pkl'), 'rb') as fp:
    #     loss_dict = pickle.load(fp)
    with open(os.path.join(model_dir, 'model_state_dict_v1.pkl'), 'rb') as fp:
        state_dict = pickle.load(fp)
    with open(os.path.join(model_dir, 'training_loss_dict_v1.pkl'), 'rb') as fp:
        loss_dict = pickle.load(fp)
    optimizer = state_dict['optimizer']
    # image_model = torch.load(os.path.join(model_dir, f'image_{backbone_type}_minloss_v2.pth'))
    # audio_model = torch.load(os.path.join(model_dir, f'audio_{backbone_type}_minloss_v2.pth'))
    # single_modal = torch.load(os.path.join(model_dir,  f'single_modal_{backbone_type}_minloss_v2.pth'))
    # cross_modal = torch.load(os.path.join(model_dir,  f'cross_modal_{backbone_type}_minloss_v2.pth'))
    image_model = torch.load(os.path.join(model_dir, f'image_{backbone_type}_minloss_v1.pth'))
    audio_model = torch.load(os.path.join(model_dir, f'audio_{backbone_type}_minloss_v1.pth'))
    single_modal = torch.load(os.path.join(model_dir, f'single_modal_{backbone_type}_minloss_v1.pth'))
    cross_modal = torch.load(os.path.join(model_dir, f'cross_modal_{backbone_type}_minloss_v1.pth'))
    if optimizer == 'SGD':
        opt = optim.SGD((list(cross_modal.parameters()) + list(single_modal.parameters()) \
                  + list(image_model.parameters()) + list(audio_model.parameters())), lr=state_dict['learning_rate'], weight_decay=5e-4, momentum=0.9)
    elif optimizer == 'Adam':
        opt = optim.Adam((list(cross_modal.parameters()) + list(single_modal.parameters()) \
                  + list(image_model.parameters()) + list(audio_model.parameters())), lr=state_dict['learning_rate'], weight_decay=5e-4)
    scheduler = StepLR(opt, step_size=10, gamma=0.1)
    return image_model, audio_model, single_modal, cross_modal, state_dict, loss_dict, opt, scheduler