from utils.util import Squared_L2dist

import torch
from torch.autograd import Function

class cfrLoss(Function):
    def __init__(self, p):
        super(cfrLoss, self).__init__()
        self.pdist = Squared_L2dist(p)
    def forward(self, image_feature, audio_feature, s_score, lcrf_data):

        image_cfr, image_audio_sim, audio_cfr, audio_image_sim = lcrf_data

        dist_IiMi = self.pdist.forward(image_feature, audio_feature, 1)
        dist_IiMj = self.pdist.forward(image_feature, audio_cfr, 1)
        dist_MiIj = self.pdist.forward(audio_feature, image_cfr, 1)

        # print(f'dist_IiMi: {dist_IiMi}, dist_IiMj: {dist_IiMj}, dist_MiIj: {dist_MiIj}')
        lcfr_ratio_I = torch.log(dist_IiMi / dist_IiMj) - torch.log(s_score / image_audio_sim)
        lcfr_ratio_M = torch.log(dist_IiMi / dist_MiIj) - torch.log(s_score / audio_image_sim)

        # lcfr_loss = lcfr_ratio_I.pow(2).mean() + lcfr_ratio_M.pow(2).mean()
        lcfr_loss = lcfr_ratio_I.pow(2).sum() + lcfr_ratio_M.pow(2).sum()


        return lcfr_loss

class cfmLoss(Function):
  def __init__(self, alpha):
      super(cfmLoss, self).__init__()
      self.alpha = torch.tensor(alpha)
  def forward(self, image_feature, music_feature):

      # image_feature = image_feature.view(image_feature.size(0), -1)
      # audio_feature = audio_feature.view(audio_feature.size(0), -1)

      # Compute squared Euclidean distance between image features and music features
        l2norm = torch.norm(torch.abs(image_feature - music_feature), p=2, dim=1)
        # if flag == True:
        # print(f'mean: {torch.mean(l2norm).item()}, min: {torch.min(l2norm).item()}, max: {torch.max(l2norm).item()}')
        l2norm_with_margin = l2norm - self.alpha
        l2norm_with_margin[l2norm_with_margin < 0] = 0
        # Compute the loss by penalizing the pairs with distances larger than alpha
        lcfm_loss = torch.sum(l2norm_with_margin)
        # print(f'tot loss {lcfm_loss}')


        return lcfm_loss


class sfrLoss(Function):
    def __init__(self, p):
        super(sfrLoss, self).__init__()
        self.pdist = Squared_L2dist(p)
    def forward(self, anchor, anchor_label, lsfr_data):

        neighbor1, neighbor2, n1_label, n2_label = lsfr_data

        # print('anchor:', anchor.shape)
        # print('anchor label:', anchor_label.shape)
        # print('n1:', neighbor1.shape)
        # print('n1 label:', n1_label.shape)

        dist_a1 = self.pdist.forward(anchor, neighbor1, 1)
        dist_l1 = self.pdist.forward(anchor_label, n1_label, 1)
        dist_a2 = self.pdist.forward(anchor, neighbor2, 1)
        dist_l2 = self.pdist.forward(anchor_label, n2_label, 1)

        lsrf_loss = torch.log(dist_a1 / dist_a2) - torch.log(dist_l1 / dist_l2)

        # lsrf_loss = lsrf_loss.pow(2).mean()
        lsrf_loss = lsrf_loss.pow(2).sum()
        return lsrf_loss