alias python3=/usr/bin/python3.9

bash
conda activate bluehairgirl
tmux attach -t cdcml

watch -n 1 nvidia-smi

To train the model:
    >> python train.py --data_dir datapath --model_dir modelpath --result_dir result_dir --batch_size 64 (for A100) / 8 (for T4) --resume